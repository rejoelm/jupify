import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { useUser } from '../contexts/UserContext';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import Sidebar from '../components/Sidebar';

const SkillTreePage: React.FC = () => {
  const navigate = useNavigate();
  const { connected, walletAddress } = useWallet();
  const { user, selectRole } = useUser();
  const [skillTree, setSkillTree] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedLevel, setSelectedLevel] = useState<number>(1);

  // Redirect if not connected
  useEffect(() => {
    if (!connected || !walletAddress) {
      navigate('/');
    }
  }, [connected, walletAddress, navigate]);

  // Fetch skill tree
  useEffect(() => {
    if (connected && walletAddress) {
      fetchSkillTree();
    }
  }, [connected, walletAddress, user?.role]);

  const fetchSkillTree = async () => {
    if (!walletAddress) return;
    
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:5000/api/quests/skills?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch skill tree');
      }
      
      const data = await response.json();
      setSkillTree(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching skill tree:', error);
      setLoading(false);
    }
  };

  const handleRoleSelect = async (role: string) => {
    try {
      await selectRole(role);
    } catch (error) {
      console.error('Error selecting role:', error);
    }
  };

  const startQuest = async (questId: number) => {
    try {
      const response = await fetch(`http://localhost:5000/api/quests/${questId}/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ wallet_address: walletAddress }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to start quest');
      }
      
      // Refresh skill tree
      fetchSkillTree();
      
    } catch (error) {
      console.error('Error starting quest:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex">
        <Sidebar />
        <div className="flex-1 p-6 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-xl">Loading skill tree...</p>
          </div>
        </div>
      </div>
    );
  }

  // Role selection screen
  if (!user?.role && skillTree?.available_roles) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex">
        <Sidebar />
        <div className="flex-1 p-6 overflow-auto">
          <div className="max-w-4xl mx-auto">
            <motion.div 
              className="mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl font-bold mb-2">Choose Your Path</h1>
              <p className="text-xl text-gray-300">Select a role to specialize in and unlock unique skill trees</p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillTree.available_roles.map((role: any) => (
                <motion.div 
                  key={role.id}
                  whileHover={{ y: -10 }}
                  className="bg-gray-800 rounded-xl overflow-hidden"
                >
                  <div className="h-40 bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
                    {role.id === 'trading' && (
                      <svg className="w-20 h-20 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                    )}
                    {role.id === 'defi' && (
                      <svg className="w-20 h-20 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    )}
                    {role.id === 'community' && (
                      <svg className="w-20 h-20 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    )}
                    {role.id === 'designer' && (
                      <svg className="w-20 h-20 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    )}
                    {role.id === 'meme' && (
                      <svg className="w-20 h-20 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    )}
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-2xl font-bold mb-2">{role.name}</h3>
                    <p className="text-gray-300 mb-6">{role.description}</p>
                    <Button 
                      onClick={() => handleRoleSelect(role.id)}
                      className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                    >
                      Choose {role.name}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <h1 className="text-4xl font-bold mr-4">{user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1)} Skill Tree</h1>
              <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm">Level {user?.level}</span>
            </div>
            <p className="text-xl text-gray-300 mt-2">Master your skills and unlock new abilities</p>
          </motion.div>
          
          {/* Level Selection */}
          <div className="flex space-x-2 mb-8 overflow-x-auto pb-2">
            {skillTree && skillTree.levels && Object.keys(skillTree.levels).map((level) => (
              <Button
                key={level}
                variant={selectedLevel === parseInt(level) ? "default" : "outline"}
                className={selectedLevel === parseInt(level) ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
                onClick={() => setSelectedLevel(parseInt(level))}
              >
                Level {level}
              </Button>
            ))}
          </div>
          
          {/* Skill Tree Grid */}
          {skillTree && skillTree.levels && skillTree.levels[selectedLevel] ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillTree.levels[selectedLevel].map((skill: any) => (
                <Card 
                  key={skill.id} 
                  className={`bg-gray-800 border-gray-700 overflow-hidden ${skill.completed ? 'border-l-4 border-l-green-500' : skill.progress > 0 ? 'border-l-4 border-l-blue-500' : ''}`}
                >
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${skill.completed ? 'bg-green-500/20' : skill.progress > 0 ? 'bg-blue-500/20' : 'bg-gray-700'}`}>
                        {skill.completed ? (
                          <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        ) : skill.progress > 0 ? (
                          <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                          </svg>
                        ) : (
                          <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                          </svg>
                        )}
                      </div>
                      <div>
                        <h3 className="font-bold">{skill.title}</h3>
                        <p className="text-sm text-gray-400">{skill.xp_reward} XP Reward</p>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-300 mb-4">{skill.description}</p>
                    
                    {skill.completed ? (
                      <div className="text-sm text-green-400">
                        Completed on {new Date(skill.completed_at).toLocaleDateString()}
                      </div>
                    ) : skill.progress > 0 ? (
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Progress</span>
                          <span>{skill.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full" 
                            style={{ width: `${skill.progress}%` }}
                          ></div>
                        </div>
                        <Button 
                          onClick={() => navigate('/quests')}
                          className="w-full mt-2 bg-blue-500 hover:bg-blue-600"
                        >
                          Continue Quest
                        </Button>
                      </div>
                    ) : (
                      <Button 
                        onClick={() => startQuest(skill.id)}
                        className="w-full bg-green-500 hover:bg-green-600"
                        disabled={user?.level < selectedLevel}
                      >
                        {user?.level < selectedLevel ? `Requires Level ${selectedLevel}` : 'Start Quest'}
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-gray-800 border-gray-700 p-8 text-center">
              <h3 className="text-xl font-bold mb-2">No Skills Available at Level {selectedLevel}</h3>
              <p className="text-gray-400 mb-4">Continue leveling up to unlock more skills</p>
              <Button 
                onClick={() => navigate('/quests')}
                className="bg-green-500 hover:bg-green-600"
              >
                View Quests
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default SkillTreePage;
