import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import Sidebar from '../components/Sidebar';

const PortfolioPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { connected, walletAddress } = useWallet();
  const [portfolios, setPortfolios] = useState<any[]>([]);
  const [selectedPortfolio, setSelectedPortfolio] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Redirect if not connected
  useEffect(() => {
    if (!connected || !walletAddress) {
      navigate('/');
    }
  }, [connected, walletAddress, navigate]);

  // Fetch portfolios
  useEffect(() => {
    if (connected && walletAddress) {
      fetchPortfolios();
    }
  }, [connected, walletAddress]);

  // Set selected portfolio based on ID
  useEffect(() => {
    if (id && portfolios.length > 0) {
      const portfolio = portfolios.find(p => p.id.toString() === id);
      if (portfolio) {
        setSelectedPortfolio(portfolio);
      }
    } else if (portfolios.length > 0 && !selectedPortfolio) {
      setSelectedPortfolio(portfolios[0]);
    }
  }, [id, portfolios, selectedPortfolio]);

  const fetchPortfolios = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:5000/api/portfolio?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch portfolios');
      }
      
      const data = await response.json();
      setPortfolios(data.portfolios || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching portfolios:', error);
      setLoading(false);
      
      // Mock data for development
      setPortfolios([
        {
          id: 1,
          name: 'Growth Portfolio',
          description: 'High-growth assets with higher risk',
          risk_profile: 'aggressive',
          created_at: '2025-05-10T14:30:00Z',
          total_value: 5280.75,
          tokens: [
            {
              id: 1,
              symbol: 'SOL',
              name: 'Solana',
              mint: 'So11111111111111111111111111111111111111112',
              amount: 25.5,
              value: 2581.88,
              current_allocation: 48.9,
              target_allocation: 50,
              price: 101.25
            },
            {
              id: 2,
              symbol: 'JUP',
              name: 'Jupiter',
              mint: 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN',
              amount: 1500,
              value: 1125.00,
              current_allocation: 21.3,
              target_allocation: 20,
              price: 0.75
            },
            {
              id: 3,
              symbol: 'BONK',
              name: 'Bonk',
              mint: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
              amount: 1500000,
              value: 1425.00,
              current_allocation: 27.0,
              target_allocation: 25,
              price: 0.00095
            },
            {
              id: 4,
              symbol: 'USDC',
              name: 'USD Coin',
              mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
              amount: 148.87,
              value: 148.87,
              current_allocation: 2.8,
              target_allocation: 5,
              price: 1.00
            }
          ]
        },
        {
          id: 2,
          name: 'Stable Income',
          description: 'Lower risk assets for stable returns',
          risk_profile: 'conservative',
          created_at: '2025-05-12T09:15:00Z',
          total_value: 3200.50,
          tokens: [
            {
              id: 5,
              symbol: 'USDC',
              name: 'USD Coin',
              mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
              amount: 1600.25,
              value: 1600.25,
              current_allocation: 50.0,
              target_allocation: 50,
              price: 1.00
            },
            {
              id: 6,
              symbol: 'mSOL',
              name: 'Marinade staked SOL',
              mint: 'mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So',
              amount: 15.17,
              value: 1600.25,
              current_allocation: 50.0,
              target_allocation: 50,
              price: 105.50
            }
          ]
        }
      ]);
    }
  };

  const createNewPortfolio = async () => {
    try {
      const name = prompt('Enter portfolio name:');
      if (!name) return;
      
      const response = await fetch('http://localhost:5000/api/portfolio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet_address: walletAddress,
          name,
          description: 'My Jupiter portfolio',
          risk_profile: 'moderate'
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create portfolio');
      }
      
      // Refresh portfolios
      fetchPortfolios();
      
    } catch (error) {
      console.error('Error creating portfolio:', error);
    }
  };

  const addToken = async () => {
    if (!selectedPortfolio) return;
    
    try {
      const symbol = prompt('Enter token symbol (e.g., SOL, JUP):');
      if (!symbol) return;
      
      const allocation = prompt('Enter target allocation percentage:');
      if (!allocation) return;
      
      const response = await fetch(`http://localhost:5000/api/portfolio/${selectedPortfolio.id}/token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet_address: walletAddress,
          symbol,
          target_allocation: parseFloat(allocation)
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to add token');
      }
      
      // Refresh portfolios
      fetchPortfolios();
      
    } catch (error) {
      console.error('Error adding token:', error);
    }
  };

  const rebalancePortfolio = async () => {
    if (!selectedPortfolio) return;
    
    try {
      const response = await fetch(`http://localhost:5000/api/portfolio/${selectedPortfolio.id}/rebalance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet_address: walletAddress
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to rebalance portfolio');
      }
      
      alert('Portfolio rebalanced successfully!');
      
      // Refresh portfolios
      fetchPortfolios();
      
    } catch (error) {
      console.error('Error rebalancing portfolio:', error);
    }
  };

  if (loading && portfolios.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex">
        <Sidebar />
        <div className="flex-1 p-6 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-xl">Loading portfolios...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex justify-between items-center">
              <h1 className="text-4xl font-bold">Portfolio Management</h1>
              <Button 
                onClick={createNewPortfolio}
                className="bg-green-500 hover:bg-green-600"
              >
                New Portfolio
              </Button>
            </div>
            <p className="text-xl text-gray-300 mt-2">Manage and track your virtual portfolios</p>
          </motion.div>
          
          {portfolios.length === 0 ? (
            <Card className="bg-gray-800 border-gray-700 p-8 text-center">
              <h3 className="text-2xl font-bold mb-4">No Portfolios Yet</h3>
              <p className="text-gray-400 mb-6">Create your first portfolio to start tracking your assets</p>
              <Button 
                onClick={createNewPortfolio}
                className="bg-green-500 hover:bg-green-600"
              >
                Create Portfolio
              </Button>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Portfolio List */}
              <div className="lg:col-span-1">
                <Card className="bg-gray-800 border-gray-700 p-6 sticky top-6">
                  <h2 className="text-xl font-bold mb-4">My Portfolios</h2>
                  
                  <div className="space-y-2">
                    {portfolios.map((portfolio) => (
                      <div 
                        key={portfolio.id}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${selectedPortfolio?.id === portfolio.id ? 'bg-green-500/20 border border-green-500/50' : 'bg-gray-700/30 hover:bg-gray-700/50'}`}
                        onClick={() => setSelectedPortfolio(portfolio)}
                      >
                        <div className="flex justify-between items-center">
                          <h3 className="font-medium">{portfolio.name}</h3>
                          <span className="text-xs px-2 py-1 bg-gray-700 rounded-full">
                            {portfolio.risk_profile}
                          </span>
                        </div>
                        <p className="text-sm text-gray-400 mt-1">${portfolio.total_value.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                  
                  <Button 
                    onClick={createNewPortfolio}
                    variant="outline"
                    className="w-full mt-4 border-gray-700 hover:border-green-500"
                  >
                    + New Portfolio
                  </Button>
                </Card>
              </div>
              
              {/* Portfolio Details */}
              {selectedPortfolio ? (
                <div className="lg:col-span-3 space-y-6">
                  {/* Portfolio Header */}
                  <Card className="bg-gray-800 border-gray-700 p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h2 className="text-2xl font-bold">{selectedPortfolio.name}</h2>
                        <p className="text-gray-400">{selectedPortfolio.description}</p>
                        <div className="flex items-center mt-2">
                          <span className="text-xs px-2 py-1 bg-gray-700 rounded-full mr-2">
                            {selectedPortfolio.risk_profile}
                          </span>
                          <span className="text-xs text-gray-400">
                            Created {new Date(selectedPortfolio.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold">${selectedPortfolio.total_value.toFixed(2)}</div>
                        <div className="text-sm text-gray-400">Total Value</div>
                      </div>
                    </div>
                  </Card>
                  
                  {/* Tabs */}
                  <div className="flex border-b border-gray-700">
                    <button 
                      className={`px-6 py-3 font-medium ${activeTab === 'overview' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
                      onClick={() => setActiveTab('overview')}
                    >
                      Overview
                    </button>
                    <button 
                      className={`px-6 py-3 font-medium ${activeTab === 'allocation' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
                      onClick={() => setActiveTab('allocation')}
                    >
                      Allocation
                    </button>
                    <button 
                      className={`px-6 py-3 font-medium ${activeTab === 'rebalance' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
                      onClick={() => setActiveTab('rebalance')}
                    >
                      Rebalance
                    </button>
                  </div>
                  
                  {/* Tab Content */}
                  {activeTab === 'overview' && (
                    <div className="space-y-6">
                      {/* Actions */}
                      <div className="flex gap-4">
                        <Button 
                          onClick={addToken}
                          className="bg-blue-500 hover:bg-blue-600"
                        >
                          Add Token
                        </Button>
                        <Button 
                          onClick={rebalancePortfolio}
                          className="bg-purple-500 hover:bg-purple-600"
                        >
                          Rebalance
                        </Button>
                      </div>
                      
                      {/* Tokens */}
                      <Card className="bg-gray-800 border-gray-700 p-6">
                        <h3 className="text-xl font-bold mb-4">Portfolio Assets</h3>
                        
                        {selectedPortfolio.tokens && selectedPortfolio.tokens.length > 0 ? (
                          <div className="overflow-x-auto">
                            <table className="w-full">
                              <thead>
                                <tr className="border-b border-gray-700">
                                  <th className="text-left py-3 px-4">Token</th>
                                  <th className="text-right py-3 px-4">Amount</th>
                                  <th className="text-right py-3 px-4">Price</th>
                                  <th className="text-right py-3 px-4">Value</th>
                                  <th className="text-right py-3 px-4">Allocation</th>
                                </tr>
                              </thead>
                              <tbody>
                                {selectedPortfolio.tokens.map((token: any) => (
                                  <tr key={token.id} className="border-b border-gray-700/50 hover:bg-gray-700/20">
                                    <td className="py-3 px-4">
                                      <div className="flex items-center">
                                        <div className="w-8 h-8 bg-gray-700 rounded-full mr-3"></div>
                                        <div>
                                          <div className="font-medium">{token.symbol}</div>
                                          <div className="text-xs text-gray-400">{token.name}</div>
                                        </div>
                                      </div>
                                    </td>
                                    <td className="text-right py-3 px-4">{token.amount.toLocaleString()}</td>
                                    <td className="text-right py-3 px-4">${token.price.toFixed(token.price < 0.01 ? 5 : 2)}</td>
                                    <td className="text-right py-3 px-4">${token.value.toFixed(2)}</td>
                                    <td className="text-right py-3 px-4">
                                      <div className="flex items-center justify-end">
                                        <span className={`mr-2 ${
                                          Math.abs(token.current_allocation - token.target_allocation) > 5
                                            ? 'text-red-400'
                                            : 'text-green-400'
                                        }`}>
                                          {token.current_allocation.toFixed(1)}%
                                        </span>
                                        <span className="text-xs text-gray-400">
                                          ({token.target_allocation}%)
                                        </span>
                                      </div>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        ) : (
                          <div className="text-center py-8 text-gray-400">
                            <p>No tokens in this portfolio</p>
                            <p className="text-sm mt-2">Click "Add Token" to get started</p>
                          </div>
                        )}
                      </Card>
                    </div>
                  )}
                  
                  {activeTab === 'allocation' && (
                    <div className="space-y-6">
                      {/* Allocation Chart */}
                      <Card className="bg-gray-800 border-gray-700 p-6">
                        <h3 className="text-xl font-bold mb-6">Current Allocation</h3>
                        
                        {selectedPortfolio.tokens && selectedPortfolio.tokens.length > 0 ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {/* Pie Chart Placeholder */}
                            <div className="flex items-center justify-center">
                              <div className="w-48 h-48 rounded-full bg-gray-700 flex items-center justify-center">
                                <span className="text-gray-400">Allocation Chart</span>
                              </div>
                            </div>
                            
                            {/* Allocation Bars */}
                            <div className="space-y-4">
                              {selectedPortfolio.tokens.map((token: any) => (
                                <div key={token.id}>
                                  <div className="flex justify-between items-center mb-1">
                                    <div className="flex items-center">
                                      <div className="w-4 h-4 bg-gray-700 rounded-full mr-2"></div>
                                      <span>{token.symbol}</span>
                                    </div>
                                    <span>{token.current_allocation.toFixed(1)}%</span>
                                  </div>
                                  <Progress 
                                    value={token.current_allocation} 
                                    className="h-2 bg-gray-700" 
                                    indicatorClassName={`${
                                      token.symbol === 'SOL' ? 'bg-purple-500' :
                                      token.symbol === 'JUP' ? 'bg-green-500' :
                                      token.symbol === 'USDC' ? 'bg-blue-500' :
                                      token.symbol === 'BONK' ? 'bg-yellow-500' :
                                      token.symbol === 'mSOL' ? 'bg-pink-500' :
                                      'bg-gray-500'
                                    }`} 
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-8 text-gray-400">
                            <p>No tokens in this portfolio</p>
                            <p className="text-sm mt-2">Add tokens to view allocation</p>
                          </div>
                        )}
                      </Card>
                      
                      {/* Target vs Current */}
                      <Card className="bg-gray-800 border-gray-700 p-6">
                        <h3 className="text-xl font-bold mb-4">Target vs Current Allocation</h3>
                        
                        {selectedPortfolio.tokens && selectedPortfolio.tokens.length > 0 ? (
                          <div className="space-y-6">
                            {selectedPortfolio.tokens.map((token: any) => (
                              <div key={token.id}>
                                <div className="flex justify-between items-center mb-2">
                                  <div className="flex items-center">
                                    <div className="w-8 h-8 bg-gray-700 rounded-full mr-3"></div>
                                    <div>
                                      <div className="font-medium">{token.symbol}</div>
                                      <div className="text-xs text-gray-400">${token.value.toFixed(2)}</div>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <div className="font-medium">
                                      <span className={Math.abs(token.current_allocation - token.target_allocation) > 5 ? 'text-red-400' : 'text-green-400'}>
                                        {token.current_allocation.toFixed(1)}%
                                      </span>
                                      {' / '}
                                      <span className="text-gray-400">{token.target_allocation}%</span>
                                    </div>
                                    <div className="text-xs text-gray-400">
                                      {token.current_allocation > token.target_allocation ? 'Overweight' : 
                                       token.current_allocation < token.target_allocation ? 'Underweight' : 'On Target'}
                                    </div>
                                  </div>
                                </div>
                                
                                <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-gray-500" 
                                    style={{ width: `${token.target_allocation}%` }}
                                  ></div>
                                  <div 
                                    className={`h-full ${
                                      Math.abs(token.current_allocation - token.target_allocation) > 5
                                        ? 'bg-red-500'
                                        : 'bg-green-500'
                                    }`}
                                    style={{ 
                                      width: `${token.current_allocation}%`,
                                      marginTop: '-8px'
                                    }}
                                  ></div>
                                </div>
                              </div>
                            ))}
                            
                            <div className="flex justify-end mt-4">
                              <Button 
                                onClick={() => setActiveTab('rebalance')}
                                className="bg-purple-500 hover:bg-purple-600"
                              >
                                Rebalance Portfolio
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-8 text-gray-400">
                            <p>No tokens in this portfolio</p>
                            <p className="text-sm mt-2">Add tokens to view allocation</p>
                          </div>
                        )}
                      </Card>
                    </div>
                  )}
                  
                  {activeTab === 'rebalance' && (
                    <div className="space-y-6">
                      <Card className="bg-gray-800 border-gray-700 p-6">
                        <h3 className="text-xl font-bold mb-4">Rebalance Portfolio</h3>
                        
                        {selectedPortfolio.tokens && selectedPortfolio.tokens.length > 0 ? (
                          <div>
                            <p className="mb-6 text-gray-300">
                              Rebalancing will adjust your portfolio to match your target allocations. This may involve swapping tokens to achieve the desired balance.
                            </p>
                            
                            <div className="space-y-4 mb-6">
                              {selectedPortfolio.tokens.map((token: any) => {
                                const diff = token.current_allocation - token.target_allocation;
                                const needsAction = Math.abs(diff) > 1;
                                
                                return (
                                  <div key={token.id} className={`p-4 rounded-lg ${needsAction ? 'bg-gray-700/50' : 'bg-gray-700/20'}`}>
                                    <div className="flex justify-between items-center">
                                      <div className="flex items-center">
                                        <div className="w-8 h-8 bg-gray-700 rounded-full mr-3"></div>
                                        <div>
                                          <div className="font-medium">{token.symbol}</div>
                                          <div className="text-xs text-gray-400">${token.value.toFixed(2)}</div>
                                        </div>
                                      </div>
                                      <div className="text-right">
                                        <div className="font-medium">
                                          <span className={Math.abs(diff) > 5 ? 'text-red-400' : Math.abs(diff) > 1 ? 'text-yellow-400' : 'text-green-400'}>
                                            {token.current_allocation.toFixed(1)}%
                                          </span>
                                          {' → '}
                                          <span className="text-gray-400">{token.target_allocation}%</span>
                                        </div>
                                        {needsAction && (
                                          <div className="text-xs text-gray-400">
                                            {diff > 0 ? 
                                              `Sell ${((diff / 100) * selectedPortfolio.total_value).toFixed(2)} USD` : 
                                              `Buy ${((Math.abs(diff) / 100) * selectedPortfolio.total_value).toFixed(2)} USD`}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                            
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="text-sm text-gray-400">
                                  Estimated gas fees: 0.001 SOL
                                </p>
                              </div>
                              <Button 
                                onClick={rebalancePortfolio}
                                className="bg-purple-500 hover:bg-purple-600"
                              >
                                Execute Rebalance
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-8 text-gray-400">
                            <p>No tokens in this portfolio</p>
                            <p className="text-sm mt-2">Add tokens before rebalancing</p>
                          </div>
                        )}
                      </Card>
                      
                      <Card className="bg-gray-800 border-gray-700 p-6">
                        <h3 className="text-xl font-bold mb-4">Rebalancing History</h3>
                        
                        <div className="text-center py-8 text-gray-400">
                          <p>No rebalancing history yet</p>
                          <p className="text-sm mt-2">Rebalance your portfolio to see history</p>
                        </div>
                      </Card>
                    </div>
                  )}
                </div>
              ) : (
                <div className="lg:col-span-3">
                  <Card className="bg-gray-800 border-gray-700 p-8 text-center">
                    <h3 className="text-xl font-bold mb-2">Select a Portfolio</h3>
                    <p className="text-gray-400">Choose a portfolio from the list to view details</p>
                  </Card>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PortfolioPage;
