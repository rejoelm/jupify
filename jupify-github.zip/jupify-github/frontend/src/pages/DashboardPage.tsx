import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { useUser } from '../contexts/UserContext';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import Sidebar from '../components/Sidebar';
import StatusWindow from '../components/StatusWindow';
import QuestCard from '../components/QuestCard';
import PortfolioWidget from '../components/PortfolioWidget';
import EventsWidget from '../components/EventsWidget';

const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { connected, walletAddress } = useWallet();
  const { user, userProgress, loading, fetchUserProgress } = useUser();
  const [activeQuests, setActiveQuests] = useState<any[]>([]);
  const [dailyQuests, setDailyQuests] = useState<any[]>([]);

  // Redirect if not connected
  useEffect(() => {
    if (!connected || !walletAddress) {
      navigate('/');
    }
  }, [connected, walletAddress, navigate]);

  // Fetch user progress and quests
  useEffect(() => {
    if (connected && walletAddress) {
      fetchUserProgress();
      fetchDailyQuests();
    }
  }, [connected, walletAddress]);

  const fetchDailyQuests = async () => {
    if (!walletAddress) return;
    
    try {
      const response = await fetch(`http://localhost:5000/api/quests/daily?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch daily quests');
      }
      
      const data = await response.json();
      setDailyQuests(data.quests || []);
    } catch (error) {
      console.error('Error fetching daily quests:', error);
    }
  };

  // Update active quests when userProgress changes
  useEffect(() => {
    if (userProgress) {
      setActiveQuests(userProgress.active_quests || []);
    }
  }, [userProgress]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-xl">Loading your adventure...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-7xl mx-auto">
          {/* Hero Banner */}
          <motion.div 
            className="relative w-full h-64 rounded-2xl overflow-hidden mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <img 
              src="/dashboard-hero.jpg" 
              alt="Dashboard Hero" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center">
              <div className="p-8">
                <h1 className="text-4xl font-bold mb-2">Welcome back, {user?.username || 'Explorer'}</h1>
                <p className="text-xl text-gray-300 mb-4">Continue your Jupiter journey</p>
                <Button className="bg-green-500 hover:bg-green-600">Today's Quests</Button>
              </div>
            </div>
          </motion.div>
          
          {/* Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Status Window */}
            <div className="lg:col-span-1">
              <StatusWindow user={user} />
              
              {/* Rewards Section */}
              <Card className="bg-gray-800 border-gray-700 p-6 mt-8">
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <span className="mr-2">🏆</span> Rewards
                </h2>
                
                <div className="space-y-4">
                  <div className="bg-gray-700/50 rounded-lg p-4 flex items-center">
                    <img src="/reward-badge.png" alt="Reward" className="w-16 h-16 rounded-lg mr-4" />
                    <div>
                      <h3 className="font-bold">Take a day off</h3>
                      <p className="text-sm text-gray-400">Complete all daily quests for 7 days</p>
                      <div className="mt-2 flex items-center">
                        <span className="text-red-400 text-xs mr-2">Not available</span>
                        <span className="text-xs text-blue-400">2500 XP required</span>
                      </div>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-gray-700 hover:bg-gray-600 text-gray-300">
                    Claim Reward
                  </Button>
                </div>
              </Card>
            </div>
            
            {/* Middle Column - Quests */}
            <div className="lg:col-span-1">
              {/* Quick Actions */}
              <Card className="bg-gray-800 border-gray-700 p-6 mb-8">
                <h2 className="text-xl font-bold mb-4">Quick Actions</h2>
                
                <div className="grid grid-cols-2 gap-4">
                  <Button className="bg-green-500/20 hover:bg-green-500/30 text-green-400 flex items-center justify-center py-6">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    New Good Habit
                  </Button>
                  
                  <Button className="bg-red-500/20 hover:bg-red-500/30 text-red-400 flex items-center justify-center py-6">
                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    New Bad Habit
                  </Button>
                </div>
                
                <div className="mt-6 space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Year: 12%</span>
                    </div>
                    <Progress value={12} className="h-2 bg-gray-700" indicatorClassName="bg-green-500" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Month: 43%</span>
                    </div>
                    <Progress value={43} className="h-2 bg-gray-700" indicatorClassName="bg-blue-500" />
                  </div>
                </div>
              </Card>
              
              {/* Daily Quests */}
              <Card className="bg-gray-800 border-gray-700 p-6">
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <span className="mr-2">📝</span> Daily Quests
                </h2>
                
                <div className="flex space-x-4 mb-6 border-b border-gray-700 pb-2">
                  <button className="text-green-400 border-b-2 border-green-400 pb-2 font-medium">Daily Quests</button>
                  <button className="text-gray-400 hover:text-white transition-colors">Quests I Did Today</button>
                  <button className="text-gray-400 hover:text-white transition-colors">Overview</button>
                </div>
                
                <div className="space-y-4">
                  {dailyQuests.length > 0 ? (
                    dailyQuests.map((quest) => (
                      <QuestCard key={quest.id} quest={quest} />
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-400">
                      <p>No daily quests available</p>
                      <p className="text-sm mt-2">Check back tomorrow for new quests</p>
                    </div>
                  )}
                </div>
              </Card>
            </div>
            
            {/* Right Column - Portfolio & Events */}
            <div className="lg:col-span-1">
              {/* Life Areas */}
              <Card className="bg-gray-800 border-gray-700 p-6 mb-8">
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <span className="mr-2">🌟</span> Life Areas
                </h2>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-500/10 rounded-lg p-4 flex flex-col items-center">
                    <div className="w-10 h-10 bg-blue-500/20 rounded-full flex items-center justify-center mb-2">
                      <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </div>
                    <span className="font-medium">Health</span>
                    <span className="text-xs text-gray-400 mt-1">All time XP earned: 0 XP</span>
                  </div>
                  
                  <div className="bg-purple-500/10 rounded-lg p-4 flex flex-col items-center">
                    <div className="w-10 h-10 bg-purple-500/20 rounded-full flex items-center justify-center mb-2">
                      <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                    <span className="font-medium">Self Improvement</span>
                    <span className="text-xs text-gray-400 mt-1">All time XP earned: 0 XP</span>
                  </div>
                  
                  <div className="bg-green-500/10 rounded-lg p-4 flex flex-col items-center">
                    <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center mb-2">
                      <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <span className="font-medium">Work</span>
                    <span className="text-xs text-gray-400 mt-1">All time XP earned: 0 XP</span>
                  </div>
                  
                  <div className="bg-pink-500/10 rounded-lg p-4 flex flex-col items-center">
                    <div className="w-10 h-10 bg-pink-500/20 rounded-full flex items-center justify-center mb-2">
                      <svg className="w-5 h-5 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <span className="font-medium">Fitness</span>
                    <span className="text-xs text-gray-400 mt-1">All time XP earned: 0 XP</span>
                  </div>
                </div>
              </Card>
              
              {/* Portfolio Widget */}
              <PortfolioWidget />
              
              {/* Events Widget */}
              <EventsWidget />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
