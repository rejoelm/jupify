import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { useUser } from '../contexts/UserContext';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import Sidebar from '../components/Sidebar';

const AchievementsPage: React.FC = () => {
  const navigate = useNavigate();
  const { connected, walletAddress } = useWallet();
  const { user } = useUser();
  const [achievements, setAchievements] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<string>('all');

  // Redirect if not connected
  useEffect(() => {
    if (!connected || !walletAddress) {
      navigate('/');
    }
  }, [connected, walletAddress, navigate]);

  // Fetch achievements
  useEffect(() => {
    if (connected && walletAddress) {
      fetchAchievements();
    }
  }, [connected, walletAddress]);

  const fetchAchievements = async () => {
    if (!walletAddress) return;
    
    try {
      setLoading(true);
      const response = await fetch(`http://localhost:5000/api/achievements?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch achievements');
      }
      
      const data = await response.json();
      setAchievements(data.achievements || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching achievements:', error);
      setLoading(false);
      
      // Mock data for development
      setAchievements([
        {
          id: 1,
          title: 'First Steps',
          description: 'Complete your first daily quest',
          category: 'beginner',
          xp_reward: 50,
          completed: true,
          completed_at: '2025-05-15T10:30:00Z',
          icon: 'footprints'
        },
        {
          id: 2,
          title: 'Portfolio Manager',
          description: 'Create your first portfolio',
          category: 'portfolio',
          xp_reward: 100,
          completed: true,
          completed_at: '2025-05-16T14:20:00Z',
          icon: 'briefcase'
        },
        {
          id: 3,
          title: 'Swap Master',
          description: 'Execute 10 swaps using Jupiter',
          category: 'trading',
          xp_reward: 200,
          completed: false,
          progress: 3,
          progress_max: 10,
          icon: 'repeat'
        },
        {
          id: 4,
          title: 'DeFi Explorer',
          description: 'Add 5 different tokens to your portfolio',
          category: 'portfolio',
          xp_reward: 150,
          completed: false,
          progress: 2,
          progress_max: 5,
          icon: 'search'
        },
        {
          id: 5,
          title: 'Consistent Learner',
          description: 'Complete daily quests for 7 consecutive days',
          category: 'beginner',
          xp_reward: 300,
          completed: false,
          progress: 3,
          progress_max: 7,
          icon: 'calendar'
        }
      ]);
    }
  };

  const filteredAchievements = achievements.filter(achievement => {
    if (filter === 'all') return true;
    if (filter === 'completed') return achievement.completed;
    if (filter === 'in-progress') return !achievement.completed && achievement.progress > 0;
    if (filter === 'locked') return !achievement.completed && (!achievement.progress || achievement.progress === 0);
    return achievement.category === filter;
  });

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'footprints':
        return (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" />
          </svg>
        );
      case 'briefcase':
        return (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
        );
      case 'repeat':
        return (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        );
      case 'search':
        return (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        );
      case 'calendar':
        return (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        );
      default:
        return (
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
          </svg>
        );
    }
  };

  if (loading && achievements.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex">
        <Sidebar />
        <div className="flex-1 p-6 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-xl">Loading achievements...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold mb-2">Achievements</h1>
            <p className="text-xl text-gray-300">Track your progress and earn rewards</p>
          </motion.div>
          
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gray-800 border-gray-700 p-6">
              <h3 className="text-lg font-medium text-gray-400 mb-2">Total Achievements</h3>
              <p className="text-3xl font-bold">{achievements.length}</p>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700 p-6">
              <h3 className="text-lg font-medium text-gray-400 mb-2">Completed</h3>
              <p className="text-3xl font-bold text-green-400">{achievements.filter(a => a.completed).length}</p>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700 p-6">
              <h3 className="text-lg font-medium text-gray-400 mb-2">In Progress</h3>
              <p className="text-3xl font-bold text-blue-400">{achievements.filter(a => !a.completed && a.progress > 0).length}</p>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700 p-6">
              <h3 className="text-lg font-medium text-gray-400 mb-2">Completion Rate</h3>
              <p className="text-3xl font-bold text-yellow-400">
                {achievements.length > 0 ? Math.round((achievements.filter(a => a.completed).length / achievements.length) * 100) : 0}%
              </p>
            </Card>
          </div>
          
          {/* Filters */}
          <div className="flex flex-wrap gap-2 mb-8">
            <Button 
              variant={filter === 'all' ? "default" : "outline"}
              className={filter === 'all' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button 
              variant={filter === 'completed' ? "default" : "outline"}
              className={filter === 'completed' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('completed')}
            >
              Completed
            </Button>
            <Button 
              variant={filter === 'in-progress' ? "default" : "outline"}
              className={filter === 'in-progress' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('in-progress')}
            >
              In Progress
            </Button>
            <Button 
              variant={filter === 'locked' ? "default" : "outline"}
              className={filter === 'locked' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('locked')}
            >
              Locked
            </Button>
            <Button 
              variant={filter === 'beginner' ? "default" : "outline"}
              className={filter === 'beginner' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('beginner')}
            >
              Beginner
            </Button>
            <Button 
              variant={filter === 'portfolio' ? "default" : "outline"}
              className={filter === 'portfolio' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('portfolio')}
            >
              Portfolio
            </Button>
            <Button 
              variant={filter === 'trading' ? "default" : "outline"}
              className={filter === 'trading' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setFilter('trading')}
            >
              Trading
            </Button>
          </div>
          
          {/* Achievements Grid */}
          {filteredAchievements.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAchievements.map((achievement) => (
                <Card 
                  key={achievement.id} 
                  className={`bg-gray-800 border-gray-700 overflow-hidden ${achievement.completed ? 'border-l-4 border-l-green-500' : achievement.progress > 0 ? 'border-l-4 border-l-blue-500' : ''}`}
                >
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${
                        achievement.completed 
                          ? 'bg-green-500/20 text-green-400' 
                          : achievement.progress > 0 
                            ? 'bg-blue-500/20 text-blue-400' 
                            : 'bg-gray-700 text-gray-400'
                      }`}>
                        {getIconComponent(achievement.icon)}
                      </div>
                      <div>
                        <h3 className="font-bold">{achievement.title}</h3>
                        <div className="flex items-center">
                          <svg className="w-4 h-4 text-yellow-400 mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                          <span className="text-sm text-yellow-400">{achievement.xp_reward} XP</span>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-sm text-gray-300 mb-4">{achievement.description}</p>
                    
                    {achievement.completed ? (
                      <div className="text-sm text-green-400">
                        Completed on {new Date(achievement.completed_at).toLocaleDateString()}
                      </div>
                    ) : achievement.progress !== undefined ? (
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs">
                          <span>Progress</span>
                          <span>{achievement.progress} / {achievement.progress_max}</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full" 
                            style={{ width: `${(achievement.progress / achievement.progress_max) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    ) : (
                      <div className="text-sm text-gray-400">
                        Not started yet
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="bg-gray-800 border-gray-700 p-8 text-center">
              <h3 className="text-xl font-bold mb-2">No Achievements Found</h3>
              <p className="text-gray-400 mb-4">Try changing your filter or complete more quests</p>
              <Button 
                onClick={() => setFilter('all')}
                className="bg-green-500 hover:bg-green-600 mr-4"
              >
                View All Achievements
              </Button>
              <Button 
                onClick={() => navigate('/quests')}
                className="bg-blue-500 hover:bg-blue-600"
              >
                Go to Quests
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default AchievementsPage;
