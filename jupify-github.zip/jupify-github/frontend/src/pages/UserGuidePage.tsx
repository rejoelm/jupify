import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import Sidebar from '../components/Sidebar';

const UserGuidePage: React.FC = () => {
  const navigate = useNavigate();
  const { connected, walletAddress, connectWallet } = useWallet();
  const [activeSection, setActiveSection] = useState<string>('intro');

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {connected && <Sidebar />}
      
      {/* Main Content */}
      <div className={`flex-1 p-6 overflow-auto ${!connected ? 'mx-auto max-w-6xl' : ''}`}>
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold mb-2">JUPIFY User Guide</h1>
            <p className="text-xl text-gray-300">Learn how to navigate the Jupiter ecosystem</p>
          </motion.div>
          
          {/* Navigation */}
          <div className="flex flex-wrap gap-2 mb-8 border-b border-gray-700 pb-4">
            <Button 
              variant={activeSection === 'intro' ? "default" : "outline"}
              className={activeSection === 'intro' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setActiveSection('intro')}
            >
              Introduction
            </Button>
            <Button 
              variant={activeSection === 'wallet' ? "default" : "outline"}
              className={activeSection === 'wallet' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setActiveSection('wallet')}
            >
              Wallet Setup
            </Button>
            <Button 
              variant={activeSection === 'portfolio' ? "default" : "outline"}
              className={activeSection === 'portfolio' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setActiveSection('portfolio')}
            >
              Portfolio Management
            </Button>
            <Button 
              variant={activeSection === 'quests' ? "default" : "outline"}
              className={activeSection === 'quests' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setActiveSection('quests')}
            >
              Quests & XP
            </Button>
            <Button 
              variant={activeSection === 'skills' ? "default" : "outline"}
              className={activeSection === 'skills' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setActiveSection('skills')}
            >
              Skill Trees
            </Button>
            <Button 
              variant={activeSection === 'assets' ? "default" : "outline"}
              className={activeSection === 'assets' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
              onClick={() => setActiveSection('assets')}
            >
              Managing Assets
            </Button>
          </div>
          
          {/* Content Sections */}
          <Card className="bg-gray-800 border-gray-700 p-8 mb-8">
            {activeSection === 'intro' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">Welcome to JUPIFY</h2>
                <p className="mb-4">
                  JUPIFY is a gamified learning platform that helps you master the Jupiter ecosystem through interactive quests, portfolio management, and skill development. This guide will walk you through the key features and how to get started.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Key Features</h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Interactive quests to learn about Jupiter's features</li>
                    <li>Portfolio management with real-time tracking</li>
                    <li>XP-based progression system with levels and rewards</li>
                    <li>Skill trees for different DeFi specializations</li>
                    <li>Achievement badges to showcase your expertise</li>
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Getting Started</h3>
                  <p className="mb-2">
                    To begin your JUPIFY journey, follow these simple steps:
                  </p>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Connect your Solana wallet</li>
                    <li>Complete the onboarding quests</li>
                    <li>Create your first portfolio</li>
                    <li>Choose a specialization path</li>
                    <li>Start earning XP and rewards</li>
                  </ol>
                </div>
                
                {!connected && (
                  <Button 
                    onClick={connectWallet}
                    className="bg-green-500 hover:bg-green-600 mt-4"
                  >
                    Connect Wallet to Start
                  </Button>
                )}
              </div>
            )}
            
            {activeSection === 'wallet' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">Wallet Setup Guide</h2>
                <p className="mb-4">
                  To use JUPIFY, you'll need a Solana wallet. This guide will help you set up a wallet and connect it to the platform.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Supported Wallets</h3>
                  <p className="mb-2">
                    JUPIFY supports all major Solana wallets, including:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Phantom</li>
                    <li>Solflare</li>
                    <li>Backpack</li>
                    <li>Glow</li>
                    <li>Other Solana-compatible wallets</li>
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Setting Up a New Wallet</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Visit the official website of your preferred wallet (e.g., <a href="https://phantom.app/" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Phantom</a>)</li>
                    <li>Download and install the browser extension or mobile app</li>
                    <li>Follow the wallet's setup instructions to create a new wallet</li>
                    <li><strong>Important:</strong> Securely store your seed phrase in a safe place. Never share it with anyone!</li>
                    <li>Add SOL to your wallet through a supported exchange or transfer</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Connecting Your Wallet to JUPIFY</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Click the "Connect Wallet" button on the JUPIFY homepage</li>
                    <li>Select your wallet from the list of available options</li>
                    <li>Approve the connection request in your wallet</li>
                    <li>Once connected, you'll be redirected to your dashboard</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Wallet Security Tips</h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Never share your seed phrase or private keys with anyone</li>
                    <li>Be cautious of phishing attempts and only use official wallet websites</li>
                    <li>Consider using a hardware wallet for additional security</li>
                    <li>Regularly update your wallet software</li>
                    <li>Disconnect your wallet when not using JUPIFY</li>
                  </ul>
                </div>
                
                {!connected && (
                  <Button 
                    onClick={connectWallet}
                    className="bg-green-500 hover:bg-green-600 mt-4"
                  >
                    Connect Wallet Now
                  </Button>
                )}
              </div>
            )}
            
            {activeSection === 'portfolio' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">Portfolio Management</h2>
                <p className="mb-4">
                  JUPIFY allows you to create and manage virtual portfolios to practice your investment strategies without risking real funds.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Creating a Portfolio</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Navigate to the Portfolio section from your dashboard</li>
                    <li>Click the "New Portfolio" button</li>
                    <li>Enter a name and description for your portfolio</li>
                    <li>Select a risk profile (Conservative, Moderate, or Aggressive)</li>
                    <li>Click "Create" to set up your portfolio</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Adding Tokens</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Open your portfolio and click "Add Token"</li>
                    <li>Search for the token you want to add</li>
                    <li>Enter the allocation percentage or amount</li>
                    <li>Click "Add" to include the token in your portfolio</li>
                    <li>Repeat for additional tokens</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Rebalancing Your Portfolio</h3>
                  <p className="mb-2">
                    Rebalancing helps maintain your desired asset allocation as market prices change:
                  </p>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>View your current portfolio allocations</li>
                    <li>Click the "Rebalance" button</li>
                    <li>Adjust allocation percentages as needed</li>
                    <li>Review the suggested trades</li>
                    <li>Confirm to execute the rebalancing</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Tracking Performance</h3>
                  <p className="mb-2">
                    JUPIFY provides tools to monitor your portfolio's performance:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Real-time value updates using Jupiter's price API</li>
                    <li>Historical performance charts</li>
                    <li>Comparison against benchmarks</li>
                    <li>Risk analysis metrics</li>
                    <li>Token allocation visualization</li>
                  </ul>
                </div>
                
                <Button 
                  onClick={() => navigate('/portfolio')}
                  className="bg-green-500 hover:bg-green-600 mt-4"
                >
                  Go to Portfolio
                </Button>
              </div>
            )}
            
            {activeSection === 'quests' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">Quests & XP System</h2>
                <p className="mb-4">
                  Quests are interactive challenges that help you learn about Jupiter's features while earning XP and rewards.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Types of Quests</h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li><strong>Daily Quests:</strong> Refresh every 24 hours and provide regular XP</li>
                    <li><strong>Achievement Quests:</strong> One-time challenges with larger XP rewards</li>
                    <li><strong>Skill Quests:</strong> Specialized challenges based on your chosen role</li>
                    <li><strong>Community Quests:</strong> Special events and limited-time challenges</li>
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Completing Quests</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Browse available quests in the Quests section</li>
                    <li>Click "Start Quest" to begin a challenge</li>
                    <li>Follow the instructions to complete the quest objectives</li>
                    <li>Click "Complete" when you've finished the requirements</li>
                    <li>Receive XP and any additional rewards</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">XP and Leveling</h3>
                  <p className="mb-2">
                    As you complete quests, you'll earn XP that contributes to your level:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Each level requires 100 XP to advance</li>
                    <li>Higher levels unlock new features and challenges</li>
                    <li>Your level is displayed on your profile and dashboard</li>
                    <li>Special rewards are granted at milestone levels (5, 10, 15, etc.)</li>
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Rewards</h3>
                  <p className="mb-2">
                    Completing quests and leveling up earns you various rewards:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>XP points for progression</li>
                    <li>Achievement badges for your profile</li>
                    <li>Access to advanced features</li>
                    <li>Special titles and status indicators</li>
                  </ul>
                </div>
                
                <Button 
                  onClick={() => navigate('/quests')}
                  className="bg-green-500 hover:bg-green-600 mt-4"
                >
                  Explore Quests
                </Button>
              </div>
            )}
            
            {activeSection === 'skills' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">Skill Trees</h2>
                <p className="mb-4">
                  Skill trees allow you to specialize in different aspects of the Jupiter ecosystem and DeFi space.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Choosing a Role</h3>
                  <p className="mb-2">
                    JUPIFY offers several specialization paths:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li><strong>Trading (Spot/Perps):</strong> Focus on trading strategies and market analysis</li>
                    <li><strong>DeFi:</strong> Specialize in decentralized finance protocols and yield strategies</li>
                    <li><strong>Community:</strong> Concentrate on community building and social aspects</li>
                    <li><strong>Designer/NFT:</strong> Focus on the creative and artistic side of Web3</li>
                    <li><strong>Meme Cult:</strong> Specialize in meme culture and viral content</li>
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Progressing Through Skill Trees</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Select your preferred role in the Skill Tree section</li>
                    <li>View the available skills organized by level</li>
                    <li>Complete skill quests to unlock new abilities</li>
                    <li>Progress deeper into your specialization as you level up</li>
                    <li>Earn role-specific rewards and achievements</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Skill Levels</h3>
                  <p className="mb-2">
                    Each skill tree has multiple levels of progression:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li><strong>Level 1:</strong> Basic introduction to the role</li>
                    <li><strong>Level 5:</strong> Intermediate concepts and strategies</li>
                    <li><strong>Level 10:</strong> Advanced techniques and optimizations</li>
                    <li><strong>Level 15:</strong> Expert-level knowledge and applications</li>
                    <li><strong>Level 20:</strong> Mastery of the specialization</li>
                  </ul>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Changing Roles</h3>
                  <p className="mb-2">
                    You can change your specialization at any time:
                  </p>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Go to the Skill Tree section</li>
                    <li>Click "Change Role"</li>
                    <li>Select a new specialization</li>
                    <li>Confirm your choice</li>
                  </ol>
                  <p className="mt-2 text-sm text-gray-400">
                    Note: Your progress in previous roles is saved, allowing you to switch back at any time.
                  </p>
                </div>
                
                <Button 
                  onClick={() => navigate('/skill-tree')}
                  className="bg-green-500 hover:bg-green-600 mt-4"
                >
                  View Skill Tree
                </Button>
              </div>
            )}
            
            {activeSection === 'assets' && (
              <div>
                <h2 className="text-2xl font-bold mb-4">Managing Assets on Solana</h2>
                <p className="mb-4">
                  This guide explains how to manage your assets on the Solana blockchain, including sending, receiving, and viewing your portfolio.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Viewing Your Assets</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Connect your wallet to JUPIFY</li>
                    <li>Navigate to the Portfolio section</li>
                    <li>View your actual wallet holdings under "My Assets"</li>
                    <li>See token balances, values, and allocation percentages</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Receiving Assets</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Go to your wallet profile or click "Receive" in your wallet</li>
                    <li>Copy your Solana wallet address</li>
                    <li>Share this address with the sender</li>
                    <li>Confirm receipt of assets in your wallet</li>
                  </ol>
                  <p className="mt-2 text-sm text-gray-400">
                    Important: Always verify the full address before receiving assets to ensure it's correct.
                  </p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Sending Assets</h3>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Open your wallet and select "Send"</li>
                    <li>Choose the token you want to send</li>
                    <li>Enter the recipient's Solana address</li>
                    <li>Specify the amount to send</li>
                    <li>Review transaction details and fees</li>
                    <li>Confirm and approve the transaction</li>
                  </ol>
                  <p className="mt-2 text-sm text-red-400">
                    Warning: Always double-check the recipient address. Blockchain transactions cannot be reversed once confirmed.
                  </p>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Using Jupiter Swap</h3>
                  <p className="mb-2">
                    JUPIFY integrates with Jupiter's swap functionality:
                  </p>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Navigate to the Swap section</li>
                    <li>Select the token you want to swap from</li>
                    <li>Select the token you want to receive</li>
                    <li>Enter the amount to swap</li>
                    <li>Review the exchange rate and fees</li>
                    <li>Click "Swap" and approve the transaction in your wallet</li>
                  </ol>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Transaction History</h3>
                  <p className="mb-2">
                    To view your transaction history:
                  </p>
                  <ol className="list-decimal pl-6 space-y-2">
                    <li>Go to your wallet profile</li>
                    <li>Select "Activity" or "History"</li>
                    <li>View all incoming and outgoing transactions</li>
                    <li>Click on any transaction for detailed information</li>
                  </ol>
                  <p className="mt-2 text-sm text-gray-400">
                    You can also view your transaction history on Solana explorers like Solscan or Explorer by searching your wallet address.
                  </p>
                </div>
                
                <Button 
                  onClick={() => navigate('/portfolio')}
                  className="bg-green-500 hover:bg-green-600 mt-4"
                >
                  Manage Your Assets
                </Button>
              </div>
            )}
          </Card>
          
          {/* Navigation Buttons */}
          <div className="flex justify-between">
            <Button 
              onClick={() => navigate('/')}
              variant="outline"
              className="border-gray-700 hover:border-green-500"
            >
              Back to Home
            </Button>
            
            {connected && (
              <Button 
                onClick={() => navigate('/dashboard')}
                className="bg-green-500 hover:bg-green-600"
              >
                Go to Dashboard
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserGuidePage;
