import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { useUser } from '../contexts/UserContext';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import Sidebar from '../components/Sidebar';
import QuestCard from '../components/QuestCard';

const QuestsPage: React.FC = () => {
  const navigate = useNavigate();
  const { connected, walletAddress } = useWallet();
  const { user } = useUser();
  const [dailyQuests, setDailyQuests] = useState<any[]>([]);
  const [achievementQuests, setAchievementQuests] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<string>('daily');
  const [loading, setLoading] = useState<boolean>(true);

  // Redirect if not connected
  useEffect(() => {
    if (!connected || !walletAddress) {
      navigate('/');
    }
  }, [connected, walletAddress, navigate]);

  // Fetch quests
  useEffect(() => {
    if (connected && walletAddress) {
      fetchQuests();
    }
  }, [connected, walletAddress, activeTab]);

  const fetchQuests = async () => {
    setLoading(true);
    
    try {
      if (activeTab === 'daily') {
        await fetchDailyQuests();
      } else if (activeTab === 'achievements') {
        await fetchAchievementQuests();
      }
    } catch (error) {
      console.error('Error fetching quests:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchDailyQuests = async () => {
    if (!walletAddress) return;
    
    try {
      const response = await fetch(`http://localhost:5000/api/quests/daily?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch daily quests');
      }
      
      const data = await response.json();
      setDailyQuests(data.quests || []);
    } catch (error) {
      console.error('Error fetching daily quests:', error);
    }
  };

  const fetchAchievementQuests = async () => {
    if (!walletAddress) return;
    
    try {
      const response = await fetch(`http://localhost:5000/api/quests/achievements?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch achievement quests');
      }
      
      const data = await response.json();
      setAchievementQuests(data.achievements || []);
    } catch (error) {
      console.error('Error fetching achievement quests:', error);
    }
  };

  if (loading && dailyQuests.length === 0 && achievementQuests.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex">
        <Sidebar />
        <div className="flex-1 p-6 flex items-center justify-center">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-xl">Loading quests...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex">
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold mb-2">Quests & Achievements</h1>
            <p className="text-xl text-gray-300">Complete quests to earn XP and unlock achievements</p>
          </motion.div>
          
          {/* Tabs */}
          <div className="flex border-b border-gray-700 mb-8">
            <button 
              className={`px-6 py-3 font-medium ${activeTab === 'daily' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
              onClick={() => setActiveTab('daily')}
            >
              Daily Quests
            </button>
            <button 
              className={`px-6 py-3 font-medium ${activeTab === 'achievements' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
              onClick={() => setActiveTab('achievements')}
            >
              Achievements
            </button>
          </div>
          
          {/* Quest Content */}
          {activeTab === 'daily' ? (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Daily Quests</h2>
                <div className="text-sm text-gray-400">
                  Resets at midnight UTC
                </div>
              </div>
              
              {dailyQuests.length > 0 ? (
                <div className="grid grid-cols-1 gap-6">
                  {dailyQuests.map((quest) => (
                    <QuestCard key={quest.id} quest={quest} />
                  ))}
                </div>
              ) : (
                <Card className="bg-gray-800 border-gray-700 p-8 text-center">
                  <h3 className="text-xl font-bold mb-2">No Daily Quests Available</h3>
                  <p className="text-gray-400 mb-4">Check back tomorrow for new quests</p>
                  <Button 
                    onClick={() => navigate('/dashboard')}
                    className="bg-green-500 hover:bg-green-600"
                  >
                    Return to Dashboard
                  </Button>
                </Card>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">Achievements</h2>
                <div className="text-sm text-gray-400">
                  {achievementQuests.filter(q => q.completed).length} / {achievementQuests.length} Completed
                </div>
              </div>
              
              {achievementQuests.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {achievementQuests.map((achievement) => (
                    <Card 
                      key={achievement.id} 
                      className={`bg-gray-800 border-gray-700 p-6 ${achievement.completed ? 'border-l-4 border-l-green-500' : ''}`}
                    >
                      <div className="flex items-center mb-4">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${achievement.completed ? 'bg-green-500/20' : 'bg-gray-700'}`}>
                          {achievement.completed ? (
                            <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          ) : (
                            <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                          )}
                        </div>
                        <div>
                          <h3 className="font-bold">{achievement.title}</h3>
                          <p className="text-sm text-gray-400">{achievement.xp_reward} XP Reward</p>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-300 mb-4">{achievement.description}</p>
                      
                      {achievement.completed ? (
                        <div className="text-sm text-green-400">
                          Completed on {new Date(achievement.completed_at).toLocaleDateString()}
                        </div>
                      ) : (
                        <Button 
                          className="w-full bg-blue-500 hover:bg-blue-600"
                          onClick={() => navigate('/dashboard')}
                        >
                          Work on this Achievement
                        </Button>
                      )}
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="bg-gray-800 border-gray-700 p-8 text-center">
                  <h3 className="text-xl font-bold mb-2">No Achievements Available</h3>
                  <p className="text-gray-400 mb-4">Complete quests to unlock achievements</p>
                  <Button 
                    onClick={() => setActiveTab('daily')}
                    className="bg-green-500 hover:bg-green-600"
                  >
                    View Daily Quests
                  </Button>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestsPage;
