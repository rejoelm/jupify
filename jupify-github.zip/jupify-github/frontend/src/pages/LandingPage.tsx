import React from 'react';
import { useWallet } from '../contexts/WalletContext';
import { Button } from '../components/ui/button';
import { motion } from 'framer-motion';

const LandingPage: React.FC = () => {
  const { connectWallet, connected, connecting } = useWallet();

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Navigation */}
      <nav className="flex justify-between items-center p-6">
        <div className="flex items-center">
          <img src="/logo.svg" alt="JUPIFY Logo" className="h-10 w-10 mr-2" />
          <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">JUPIFY</span>
        </div>
        <div className="flex items-center space-x-6">
          <a href="/about" className="hover:text-green-400 transition-colors">ABOUT</a>
          <a href="/guide" className="hover:text-green-400 transition-colors">GUIDE</a>
          <a href="/contact" className="hover:text-green-400 transition-colors">CONTACT</a>
          {connected ? (
            <Button asChild>
              <a href="/dashboard" className="bg-gradient-to-r from-green-500 to-blue-500 text-white px-6 py-2 rounded-full font-bold">
                DASHBOARD
              </a>
            </Button>
          ) : (
            <Button 
              onClick={connectWallet} 
              disabled={connecting}
              className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-6 py-2 rounded-full font-bold"
            >
              {connecting ? 'Connecting...' : 'CONNECT WALLET'}
            </Button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        {/* Animated background */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black opacity-70"></div>
          <div className="absolute inset-0 bg-gradient-radial from-green-900/20 to-transparent"></div>
          
          {/* Animated particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full bg-green-500"
              initial={{ 
                x: Math.random() * window.innerWidth, 
                y: Math.random() * window.innerHeight,
                opacity: Math.random() * 0.5 + 0.3
              }}
              animate={{ 
                x: Math.random() * window.innerWidth, 
                y: Math.random() * window.innerHeight,
                opacity: [0.3, 0.8, 0.3]
              }}
              transition={{ 
                duration: Math.random() * 20 + 10, 
                repeat: Infinity,
                ease: "linear"
              }}
            />
          ))}
        </div>

        <div className="container mx-auto px-6 z-10">
          <div className="max-w-4xl mx-auto text-center">
            <motion.h1 
              className="text-6xl md:text-8xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <span className="block">The World of</span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-500">JUPIFY</span>
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl mb-10 text-gray-300"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              Learn, Earn, and Master Jupiter's DeFi Universe
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              {connected ? (
                <Button asChild className="bg-green-500 hover:bg-green-600 text-white px-10 py-6 rounded-full text-xl font-bold">
                  <a href="/dashboard">LAUNCH PORTAL</a>
                </Button>
              ) : (
                <Button 
                  onClick={connectWallet} 
                  disabled={connecting}
                  className="bg-green-500 hover:bg-green-600 text-white px-10 py-6 rounded-full text-xl font-bold"
                >
                  {connecting ? 'Connecting...' : 'LAUNCH PORTAL'}
                </Button>
              )}
            </motion.div>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <span className="text-sm uppercase tracking-widest mb-2">SCROLL</span>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 5V19M12 19L5 12M12 19L19 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Master the Jupiter Ecosystem</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {/* Feature 1 */}
            <motion.div 
              className="bg-gray-800 rounded-xl p-8 hover:bg-gray-700 transition-colors"
              whileHover={{ y: -10 }}
            >
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-6">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 6L15 12L9 18" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">Daily Quests</h3>
              <p className="text-gray-400">Complete interactive challenges to learn about Jupiter's features while earning XP and rewards.</p>
            </motion.div>
            
            {/* Feature 2 */}
            <motion.div 
              className="bg-gray-800 rounded-xl p-8 hover:bg-gray-700 transition-colors"
              whileHover={{ y: -10 }}
            >
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mb-6">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">Skill Trees</h3>
              <p className="text-gray-400">Specialize in different DeFi roles and build your expertise through customized learning paths.</p>
            </motion.div>
            
            {/* Feature 3 */}
            <motion.div 
              className="bg-gray-800 rounded-xl p-8 hover:bg-gray-700 transition-colors"
              whileHover={{ y: -10 }}
            >
              <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mb-6">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 7H4M20 7V19C20 20.1046 19.1046 21 18 21H6C4.89543 21 4 20.1046 4 19V7M20 7L17 3H7L4 7M8 11H16M8 15H16" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">Real Rewards</h3>
              <p className="text-gray-400">Earn XP, badges, and unlock special features as you progress through your Jupiter journey.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Join the Community</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {/* Events */}
            <div className="bg-gray-800 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-6">Upcoming Events</h3>
              
              <div className="space-y-6">
                <div className="border-l-4 border-green-500 pl-4">
                  <h4 className="text-xl font-bold">Jupiter Trading Competition</h4>
                  <p className="text-gray-400 mb-2">May 25, 2025</p>
                  <p>Compete with other traders for prizes and glory in Jupiter's biggest trading event.</p>
                </div>
                
                <div className="border-l-4 border-blue-500 pl-4">
                  <h4 className="text-xl font-bold">DeFi Masterclass</h4>
                  <p className="text-gray-400 mb-2">June 3, 2025</p>
                  <p>Learn advanced DeFi strategies from Jupiter's top experts.</p>
                </div>
              </div>
            </div>
            
            {/* Stats */}
            <div className="bg-gray-800 rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-6">Community Stats</h3>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <span className="block text-5xl font-bold text-green-500">10K+</span>
                  <span className="text-gray-400">Active Users</span>
                </div>
                
                <div className="text-center">
                  <span className="block text-5xl font-bold text-blue-500">500K+</span>
                  <span className="text-gray-400">Quests Completed</span>
                </div>
                
                <div className="text-center">
                  <span className="block text-5xl font-bold text-purple-500">50M+</span>
                  <span className="text-gray-400">XP Earned</span>
                </div>
                
                <div className="text-center">
                  <span className="block text-5xl font-bold text-yellow-500">100K+</span>
                  <span className="text-gray-400">Badges Awarded</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-6 md:mb-0">
              <img src="/logo.svg" alt="JUPIFY Logo" className="h-8 w-8 mr-2" />
              <span className="text-xl font-bold">JUPIFY</span>
            </div>
            
            <div className="flex space-x-6 mb-6 md:mb-0">
              <a href="https://twitter.com/jupiterexchange" className="hover:text-green-400 transition-colors">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M23 3.01006C22.0424 3.68553 20.9821 4.20217 19.86 4.54006C19.2577 3.84757 18.4573 3.35675 17.567 3.13398C16.6767 2.91122 15.7395 2.96725 14.8821 3.29451C14.0247 3.62177 13.2884 4.20446 12.773 4.96377C12.2575 5.72309 11.9877 6.62239 12 7.54006V8.54006C10.2426 8.58562 8.50127 8.19587 6.93101 7.4055C5.36074 6.61513 4.01032 5.44869 3 4.01006C3 4.01006 -1 13.0101 8 17.0101C5.94053 18.408 3.48716 19.109 1 19.0101C10 24.0101 21 19.0101 21 7.51006C20.9991 7.23151 20.9723 6.95365 20.92 6.68006C21.9406 5.67355 22.6608 4.40277 23 3.01006Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </a>
              <a href="https://discord.gg/jup" className="hover:text-green-400 transition-colors">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 11.5C9 12.3284 8.32843 13 7.5 13C6.67157 13 6 12.3284 6 11.5C6 10.6716 6.67157 10 7.5 10C8.32843 10 9 10.6716 9 11.5Z" fill="currentColor"/>
                  <path d="M16.5 13C17.3284 13 18 12.3284 18 11.5C18 10.6716 17.3284 10 16.5 10C15.6716 10 15 10.6716 15 11.5C15 12.3284 15.6716 13 16.5 13Z" fill="currentColor"/>
                  <path d="M18.25 4H5.75C4.23122 4 3 5.23122 3 6.75V17.25C3 18.7688 4.23122 20 5.75 20H18.25C19.7688 20 21 18.7688 21 17.25V6.75C21 5.23122 19.7688 4 18.25 4ZM13.3536 15.2322C13.2603 15.3255 13.1326 15.3789 13 15.3789C12.8674 15.3789 12.7397 15.3255 12.6464 15.2322C11.2054 13.7911 8.96512 13.2574 7.25 13.625C7.08126 13.6623 6.90936 13.6116 6.78329 13.4855C6.65723 13.3595 6.59458 13.1831 6.61224 13.0044C6.62991 12.8256 6.72679 12.6647 6.87538 12.5648C7.02397 12.4648 7.20783 12.4361 7.375 12.4875C9.45988 12.0099 12.0446 12.6099 13.7071 14.2725C13.8004 14.3658 13.8538 14.4935 13.8538 14.6261C13.8538 14.7587 13.8004 14.8864 13.7071 14.9797L13.3536 15.2322ZM16.625 12.4875C16.7922 12.4361 16.976 12.4648 17.1246 12.5648C17.2732 12.6647 17.3701 12.8256 17.3878 13.0044C17.4054 13.1831 17.3428 13.3595 17.2167 13.4855C17.0906 13.6116 16.9187 13.6623 16.75 13.625C15.0349 13.2574 12.7946 13.7911 11.3536 15.2322C11.2603 15.3255 11.1326 15.3789 11 15.3789C10.8674 15.3789 10.7397 15.3255 10.6464 15.2322L10.2929 14.9797C10.1996 14.8864 10.1462 14.7587 10.1462 14.6261C10.1462 14.4935 10.1996 14.3658 10.2929 14.2725C11.9554 12.6099 14.5401 12.0099 16.625 12.4875Z" fill="currentColor"/>
                </svg>
              </a>
              <a href="https://t.me/jupiterexchange" className="hover:text-green-400 transition-colors">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </a>
            </div>
            
            <div className="text-sm text-gray-500">
              © 2025 JUPIFY. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
