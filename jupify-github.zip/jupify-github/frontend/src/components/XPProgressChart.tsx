import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';

const XPProgressChart: React.FC = () => {
  const [xpData, setXPData] = useState<any[]>([]);
  const [timeRange, setTimeRange] = useState<string>('1m'); // 1w, 1m, 3m, 1y, all
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>('xp');

  useEffect(() => {
    fetchXPHistory();
  }, [timeRange]);

  const fetchXPHistory = async () => {
    try {
      setLoading(true);
      const walletAddress = localStorage.getItem('jupify-wallet-address');
      if (!walletAddress) {
        setLoading(false);
        return;
      }
      
      const response = await fetch(`http://localhost:5000/api/xp/history?wallet_address=${walletAddress}&range=${timeRange}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch XP history');
      }
      
      const data = await response.json();
      setXPData(data.history || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching XP history:', error);
      setLoading(false);
      
      // Mock data for development
      generateMockData();
    }
  };

  const generateMockData = () => {
    // Generate realistic mock data based on time range
    const mockData = [];
    const now = new Date();
    let dataPoints = 30; // Default for 1m
    
    if (timeRange === '1w') dataPoints = 7;
    if (timeRange === '3m') dataPoints = 90;
    if (timeRange === '1y') dataPoints = 365;
    if (timeRange === 'all') dataPoints = 730;
    
    // Start with a base XP and add some randomness
    let totalXP = 0;
    let level = 1;
    
    const questTypes = ['daily', 'achievement', 'portfolio', 'trading', 'community'];
    
    for (let i = dataPoints; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      // Add some randomness to daily XP gain
      const dailyXP = Math.floor(Math.random() * 30) + 10;
      totalXP += dailyXP;
      
      // Calculate level based on XP (100 XP per level)
      level = Math.floor(totalXP / 100) + 1;
      
      // Generate random quest completions
      const questsCompleted = Math.floor(Math.random() * 3) + 1;
      
      // Generate random quest type distribution
      const questDistribution = {};
      let remainingQuests = questsCompleted;
      
      questTypes.forEach((type, index) => {
        if (index === questTypes.length - 1) {
          questDistribution[type] = remainingQuests;
        } else {
          const typeCount = Math.min(Math.floor(Math.random() * remainingQuests) + (index === 0 ? 1 : 0), remainingQuests);
          questDistribution[type] = typeCount;
          remainingQuests -= typeCount;
        }
      });
      
      mockData.push({
        date: date.toISOString().split('T')[0],
        xp: totalXP,
        level,
        dailyXP,
        questsCompleted,
        questDistribution
      });
    }
    
    setXPData(mockData);
  };

  const calculateGrowth = () => {
    if (xpData.length < 2) return { value: 0, percentage: 0 };
    
    const firstValue = xpData[0].xp;
    const lastValue = xpData[xpData.length - 1].xp;
    const growth = lastValue - firstValue;
    const percentage = firstValue > 0 ? (growth / firstValue) * 100 : 100;
    
    return { value: growth, percentage };
  };

  const growth = calculateGrowth();
  
  // Calculate daily XP data for bar chart
  const dailyXPData = xpData.map(day => ({
    date: day.date,
    xp: day.dailyXP || 0
  }));
  
  // Calculate quest distribution data for pie chart
  const getQuestDistributionData = () => {
    if (xpData.length === 0) return [];
    
    const latestData = xpData[xpData.length - 1];
    if (!latestData.questDistribution) return [];
    
    return Object.entries(latestData.questDistribution).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value
    }));
  };
  
  const questDistributionData = getQuestDistributionData();
  
  const COLORS = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6'];

  return (
    <Card className="bg-gray-800 border-gray-700 p-6 mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">XP & Achievement Progress</h2>
        
        <div className="flex space-x-2">
          <Button 
            variant={timeRange === '1w' ? "default" : "outline"}
            className={timeRange === '1w' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('1w')}
            size="sm"
          >
            1W
          </Button>
          <Button 
            variant={timeRange === '1m' ? "default" : "outline"}
            className={timeRange === '1m' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('1m')}
            size="sm"
          >
            1M
          </Button>
          <Button 
            variant={timeRange === '3m' ? "default" : "outline"}
            className={timeRange === '3m' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('3m')}
            size="sm"
          >
            3M
          </Button>
          <Button 
            variant={timeRange === '1y' ? "default" : "outline"}
            className={timeRange === '1y' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('1y')}
            size="sm"
          >
            1Y
          </Button>
          <Button 
            variant={timeRange === 'all' ? "default" : "outline"}
            className={timeRange === 'all' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('all')}
            size="sm"
          >
            All
          </Button>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="flex border-b border-gray-700 mb-6">
        <button 
          className={`px-4 py-2 font-medium ${activeTab === 'xp' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
          onClick={() => setActiveTab('xp')}
        >
          XP Growth
        </button>
        <button 
          className={`px-4 py-2 font-medium ${activeTab === 'daily' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
          onClick={() => setActiveTab('daily')}
        >
          Daily XP
        </button>
        <button 
          className={`px-4 py-2 font-medium ${activeTab === 'quests' ? 'text-green-400 border-b-2 border-green-400' : 'text-gray-400 hover:text-white'}`}
          onClick={() => setActiveTab('quests')}
        >
          Quest Distribution
        </button>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-12 h-12 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin"></div>
        </div>
      ) : xpData.length > 0 ? (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-1">Current Level</div>
              <div className="text-2xl font-bold text-yellow-400">
                Level {xpData[xpData.length - 1].level}
              </div>
            </div>
            
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-1">Total XP</div>
              <div className="text-2xl font-bold">
                {xpData[xpData.length - 1].xp} XP
              </div>
            </div>
            
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-1">XP Growth ({timeRange})</div>
              <div className="text-2xl font-bold text-green-400">
                +{growth.value} XP ({growth.percentage.toFixed(2)}%)
              </div>
            </div>
          </div>
          
          <div className="h-80">
            {activeTab === 'xp' && (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={xpData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#9CA3AF"
                    tick={{ fill: '#9CA3AF' }}
                    tickLine={{ stroke: '#4B5563' }}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    tick={{ fill: '#9CA3AF' }}
                    tickLine={{ stroke: '#4B5563' }}
                    tickFormatter={(value) => `${value} XP`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      borderColor: '#374151',
                      color: '#F9FAFB'
                    }}
                    formatter={(value: any) => [`${value} XP`, 'Total XP']}
                    labelFormatter={(label) => `Date: ${label}`}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="xp" 
                    stroke="#FBBF24" 
                    strokeWidth={2}
                    dot={{ r: 3, fill: '#FBBF24' }}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
            
            {activeTab === 'daily' && (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={dailyXPData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#9CA3AF"
                    tick={{ fill: '#9CA3AF' }}
                    tickLine={{ stroke: '#4B5563' }}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    tick={{ fill: '#9CA3AF' }}
                    tickLine={{ stroke: '#4B5563' }}
                    tickFormatter={(value) => `${value} XP`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      borderColor: '#374151',
                      color: '#F9FAFB'
                    }}
                    formatter={(value: any) => [`${value} XP`, 'Daily XP']}
                    labelFormatter={(label) => `Date: ${label}`}
                  />
                  <Bar 
                    dataKey="xp" 
                    fill="#10B981" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
            
            {activeTab === 'quests' && (
              <div className="flex items-center justify-center h-full">
                {questDistributionData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={questDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={120}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {questDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          borderColor: '#374151',
                          color: '#F9FAFB'
                        }}
                        formatter={(value: any) => [`${value} quests`, 'Completed']}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-center text-gray-400">
                    <p>No quest data available</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="text-center py-16 text-gray-400">
          <p>No XP history available</p>
          <p className="text-sm mt-2">Complete quests to earn XP and track progress</p>
        </div>
      )}
    </Card>
  );
};

export default XPProgressChart;
