import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';

const PortfolioProgressChart: React.FC = () => {
  const [portfolioData, setPortfolioData] = useState<any[]>([]);
  const [timeRange, setTimeRange] = useState<string>('1m'); // 1w, 1m, 3m, 1y, all
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchPortfolioHistory();
  }, [timeRange]);

  const fetchPortfolioHistory = async () => {
    try {
      setLoading(true);
      const walletAddress = localStorage.getItem('jupify-wallet-address');
      if (!walletAddress) {
        setLoading(false);
        return;
      }
      
      const response = await fetch(`http://localhost:5000/api/portfolio/history?wallet_address=${walletAddress}&range=${timeRange}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch portfolio history');
      }
      
      const data = await response.json();
      setPortfolioData(data.history || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching portfolio history:', error);
      setLoading(false);
      
      // Mock data for development
      generateMockData();
    }
  };

  const generateMockData = () => {
    // Generate realistic mock data based on time range
    const mockData = [];
    const now = new Date();
    let dataPoints = 30; // Default for 1m
    
    if (timeRange === '1w') dataPoints = 7;
    if (timeRange === '3m') dataPoints = 90;
    if (timeRange === '1y') dataPoints = 365;
    if (timeRange === 'all') dataPoints = 730;
    
    // Start with a base value and add some randomness
    let baseValue = 5000;
    
    for (let i = dataPoints; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      // Add some randomness but with an overall upward trend
      const randomChange = (Math.random() - 0.3) * 100; // Slightly biased toward positive
      baseValue += randomChange;
      
      mockData.push({
        date: date.toISOString().split('T')[0],
        value: Math.max(baseValue, 100), // Ensure value doesn't go too low
        xp: Math.floor(100 + (dataPoints - i) * 10 + Math.random() * 20),
        questsCompleted: Math.floor((dataPoints - i) * 0.3 + Math.random() * 2)
      });
    }
    
    setPortfolioData(mockData);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const calculateGrowth = () => {
    if (portfolioData.length < 2) return { value: 0, percentage: 0 };
    
    const firstValue = portfolioData[0].value;
    const lastValue = portfolioData[portfolioData.length - 1].value;
    const growth = lastValue - firstValue;
    const percentage = (growth / firstValue) * 100;
    
    return { value: growth, percentage };
  };

  const growth = calculateGrowth();

  return (
    <Card className="bg-gray-800 border-gray-700 p-6 mb-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Portfolio Progress</h2>
        
        <div className="flex space-x-2">
          <Button 
            variant={timeRange === '1w' ? "default" : "outline"}
            className={timeRange === '1w' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('1w')}
            size="sm"
          >
            1W
          </Button>
          <Button 
            variant={timeRange === '1m' ? "default" : "outline"}
            className={timeRange === '1m' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('1m')}
            size="sm"
          >
            1M
          </Button>
          <Button 
            variant={timeRange === '3m' ? "default" : "outline"}
            className={timeRange === '3m' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('3m')}
            size="sm"
          >
            3M
          </Button>
          <Button 
            variant={timeRange === '1y' ? "default" : "outline"}
            className={timeRange === '1y' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('1y')}
            size="sm"
          >
            1Y
          </Button>
          <Button 
            variant={timeRange === 'all' ? "default" : "outline"}
            className={timeRange === 'all' ? "bg-green-500 hover:bg-green-600" : "border-gray-700 hover:border-green-500"}
            onClick={() => setTimeRange('all')}
            size="sm"
          >
            All
          </Button>
        </div>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-12 h-12 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin"></div>
        </div>
      ) : portfolioData.length > 0 ? (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-1">Current Value</div>
              <div className="text-2xl font-bold">
                {formatCurrency(portfolioData[portfolioData.length - 1].value)}
              </div>
            </div>
            
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-1">Growth ({timeRange})</div>
              <div className={`text-2xl font-bold ${growth.value >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(growth.value)} ({growth.percentage.toFixed(2)}%)
              </div>
            </div>
            
            <div className="bg-gray-700/30 rounded-lg p-4">
              <div className="text-sm text-gray-400 mb-1">Total XP Earned</div>
              <div className="text-2xl font-bold text-yellow-400">
                {portfolioData[portfolioData.length - 1].xp} XP
              </div>
            </div>
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={portfolioData}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="date" 
                  stroke="#9CA3AF"
                  tick={{ fill: '#9CA3AF' }}
                  tickLine={{ stroke: '#4B5563' }}
                />
                <YAxis 
                  stroke="#9CA3AF"
                  tick={{ fill: '#9CA3AF' }}
                  tickLine={{ stroke: '#4B5563' }}
                  tickFormatter={(value) => `$${value.toLocaleString()}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    borderColor: '#374151',
                    color: '#F9FAFB'
                  }}
                  formatter={(value: any) => [formatCurrency(value), 'Portfolio Value']}
                  labelFormatter={(label) => `Date: ${label}`}
                />
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#10B981" 
                  fillOpacity={1} 
                  fill="url(#colorValue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      ) : (
        <div className="text-center py-16 text-gray-400">
          <p>No portfolio history available</p>
          <p className="text-sm mt-2">Start building your portfolio to track progress</p>
        </div>
      )}
    </Card>
  );
};

export default PortfolioProgressChart;
