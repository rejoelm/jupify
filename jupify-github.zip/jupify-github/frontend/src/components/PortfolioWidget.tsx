import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

const PortfolioWidget: React.FC = () => {
  const [portfolios, setPortfolios] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    fetchPortfolios();
  }, []);

  const fetchPortfolios = async () => {
    try {
      const walletAddress = localStorage.getItem('jupify-wallet-address');
      if (!walletAddress) {
        setLoading(false);
        return;
      }
      
      const response = await fetch(`http://localhost:5000/api/portfolio?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch portfolios');
      }
      
      const data = await response.json();
      setPortfolios(data.portfolios || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching portfolios:', error);
      setLoading(false);
    }
  };

  const createNewPortfolio = async () => {
    try {
      const walletAddress = localStorage.getItem('jupify-wallet-address');
      if (!walletAddress) return;
      
      const name = prompt('Enter portfolio name:');
      if (!name) return;
      
      const response = await fetch('http://localhost:5000/api/portfolio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet_address: walletAddress,
          name,
          description: 'My Jupiter portfolio',
          risk_profile: 'moderate'
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create portfolio');
      }
      
      // Refresh portfolios
      fetchPortfolios();
      
    } catch (error) {
      console.error('Error creating portfolio:', error);
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700 p-6 mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold flex items-center">
          <span className="mr-2">💼</span> My Portfolios
        </h2>
        <Button 
          onClick={createNewPortfolio}
          className="bg-green-500 hover:bg-green-600 text-xs py-1 px-3 h-auto"
        >
          New Portfolio
        </Button>
      </div>
      
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="w-8 h-8 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin"></div>
        </div>
      ) : portfolios.length > 0 ? (
        <div className="space-y-4">
          {portfolios.map((portfolio) => (
            <div key={portfolio.id} className="bg-gray-700/30 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-bold">{portfolio.name}</h3>
                <span className="text-sm text-gray-400">{portfolio.risk_profile}</span>
              </div>
              
              <p className="text-sm text-gray-300 mb-3">{portfolio.description || 'No description'}</p>
              
              <div className="flex justify-between items-center">
                <div className="text-sm">
                  <span className="text-gray-400">Value: </span>
                  <span className="text-green-400">${portfolio.total_value.toFixed(2)}</span>
                </div>
                
                <Button 
                  asChild
                  className="bg-blue-500 hover:bg-blue-600 text-xs py-1 px-3 h-auto"
                >
                  <a href={`/portfolio/${portfolio.id}`}>View</a>
                </Button>
              </div>
              
              {portfolio.tokens && portfolio.tokens.length > 0 && (
                <div className="mt-4 grid grid-cols-2 gap-2">
                  {portfolio.tokens.slice(0, 4).map((token: any) => (
                    <div key={token.id} className="bg-gray-800/50 rounded p-2 flex items-center">
                      <div className="w-6 h-6 bg-gray-700 rounded-full mr-2"></div>
                      <div>
                        <div className="text-xs font-medium">{token.symbol}</div>
                        <div className="text-xs text-gray-400">{token.current_allocation.toFixed(1)}%</div>
                      </div>
                    </div>
                  ))}
                  
                  {portfolio.tokens.length > 4 && (
                    <div className="bg-gray-800/50 rounded p-2 flex items-center justify-center">
                      <span className="text-xs text-gray-400">+{portfolio.tokens.length - 4} more</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-400">
          <p>No portfolios yet</p>
          <p className="text-sm mt-2">Create your first portfolio to start tracking your assets</p>
        </div>
      )}
    </Card>
  );
};

export default PortfolioWidget;
