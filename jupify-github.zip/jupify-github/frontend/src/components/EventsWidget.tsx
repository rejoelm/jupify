import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';

const EventsWidget: React.FC = () => {
  const [events, setEvents] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/events');
      
      if (!response.ok) {
        throw new Error('Failed to fetch events');
      }
      
      const data = await response.json();
      setEvents(data.events || []);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching events:', error);
      setLoading(false);
      
      // Mock data for development
      setEvents([
        {
          id: 1,
          type: 'community',
          title: 'Jupiter Trading Competition',
          description: 'Compete with other traders for prizes and glory in Jupiter\'s biggest trading event.',
          start_date: '2025-05-25T00:00:00Z',
          end_date: '2025-05-30T00:00:00Z',
          location: 'Online',
          url: 'https://jup.ag/events/trading-competition'
        },
        {
          id: 2,
          type: 'ecosystem',
          title: 'DeFi Masterclass',
          description: 'Learn advanced DeFi strategies from Jupiter\'s top experts.',
          start_date: '2025-06-03T00:00:00Z',
          end_date: '2025-06-03T00:00:00Z',
          location: 'Online',
          url: 'https://jup.ag/events/defi-masterclass'
        }
      ]);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };

  return (
    <Card className="bg-gray-800 border-gray-700 p-6">
      <h2 className="text-xl font-bold mb-4 flex items-center">
        <span className="mr-2">🎉</span> Upcoming Events
      </h2>
      
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="w-8 h-8 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin"></div>
        </div>
      ) : events.length > 0 ? (
        <div className="space-y-4">
          {events.map((event) => (
            <div key={event.id} className="bg-gray-700/30 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold">{event.title}</h3>
                <span className="text-xs px-2 py-1 bg-green-500/20 text-green-400 rounded">
                  {event.type === 'community' ? 'Community' : 'Ecosystem'}
                </span>
              </div>
              
              <p className="text-sm text-gray-300 mb-3">{event.description}</p>
              
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-400">
                  {formatDate(event.start_date)}
                </div>
                
                <Button 
                  asChild
                  className="bg-blue-500 hover:bg-blue-600 text-xs py-1 px-3 h-auto"
                >
                  <a href={event.url} target="_blank" rel="noopener noreferrer">Details</a>
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-400">
          <p>No upcoming events</p>
          <p className="text-sm mt-2">Check back later for new events</p>
        </div>
      )}
    </Card>
  );
};

export default EventsWidget;
