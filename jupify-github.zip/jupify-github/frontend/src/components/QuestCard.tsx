import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

interface QuestCardProps {
  quest: any;
}

const QuestCard: React.FC<QuestCardProps> = ({ quest }) => {
  const startQuest = async () => {
    try {
      const walletAddress = localStorage.getItem('jupify-wallet-address');
      if (!walletAddress) return;
      
      const response = await fetch(`http://localhost:5000/api/quests/${quest.id}/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ wallet_address: walletAddress }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to start quest');
      }
      
      // Refresh page to update quest status
      window.location.reload();
      
    } catch (error) {
      console.error('Error starting quest:', error);
    }
  };
  
  const completeQuest = async () => {
    try {
      const walletAddress = localStorage.getItem('jupify-wallet-address');
      if (!walletAddress) return;
      
      const response = await fetch(`http://localhost:5000/api/quests/${quest.id}/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ wallet_address: walletAddress }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to complete quest');
      }
      
      const result = await response.json();
      
      // Show reward notification
      alert(`Quest completed! You earned ${result.xp_awarded} XP${result.level_up ? ' and leveled up!' : '!'}`);
      
      // Refresh page to update quest status
      window.location.reload();
      
    } catch (error) {
      console.error('Error completing quest:', error);
    }
  };

  return (
    <Card className="bg-gray-700/30 hover:bg-gray-700/50 transition-colors border-gray-600 overflow-hidden">
      <div className="flex">
        {/* Quest Image */}
        <div className="w-1/3">
          <img 
            src={`/quest-${quest.type || 'daily'}.jpg`} 
            alt={quest.title} 
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = '/quest-default.jpg';
            }}
          />
        </div>
        
        {/* Quest Content */}
        <div className="w-2/3 p-4">
          <div className="flex items-center mb-2">
            <svg className="w-5 h-5 mr-2 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="font-bold">{quest.title}</h3>
          </div>
          
          <p className="text-sm text-gray-300 mb-3">{quest.description}</p>
          
          <div className="flex items-center text-xs text-gray-400 mb-3">
            <span className="mr-2">Complete it to earn:</span>
            <span className="text-yellow-400 mr-1">{quest.xp_reward} XP</span>
            <svg className="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
          </div>
          
          {quest.user_progress !== undefined && (
            <div className="mb-3">
              <div className="flex justify-between text-xs mb-1">
                <span>Progress</span>
                <span>{quest.user_progress}%</span>
              </div>
              <Progress 
                value={quest.user_progress} 
                className="h-1 bg-gray-600" 
                indicatorClassName="bg-green-500" 
              />
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <div className="text-xs text-gray-400">
              {quest.started ? 'Incomplete yet !!' : 'Not started'}
            </div>
            
            {quest.started ? (
              <Button 
                onClick={completeQuest}
                className="bg-green-500 hover:bg-green-600 text-xs py-1 px-3 h-auto"
              >
                Complete
              </Button>
            ) : (
              <Button 
                onClick={startQuest}
                className="bg-blue-500 hover:bg-blue-600 text-xs py-1 px-3 h-auto"
              >
                Start Quest
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default QuestCard;
