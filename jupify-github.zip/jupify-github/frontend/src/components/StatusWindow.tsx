import React from 'react';
import { motion } from 'framer-motion';
import { Card } from './ui/card';
import { Progress } from './ui/progress';

interface StatusWindowProps {
  user: any;
}

const StatusWindow: React.FC<StatusWindowProps> = ({ user }) => {
  return (
    <Card className="bg-gray-800 border-gray-700 p-6">
      <h2 className="text-xl font-bold mb-4">Status Window</h2>
      
      {/* Profile Section */}
      <div className="flex items-center mb-6">
        <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center mr-4">
          <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </div>
        <div>
          <div className="flex items-center">
            <h3 className="font-bold">{user?.username || 'My Profile'}</h3>
            <svg className="w-4 h-4 ml-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </div>
      
      {/* Character Image */}
      <div className="relative mb-6">
        <div className="bg-gray-700 rounded-lg overflow-hidden">
          <img 
            src="/character-desk.jpg" 
            alt="Character Desk" 
            className="w-full h-48 object-cover"
          />
        </div>
        
        <div className="absolute bottom-4 left-4">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center mr-2">
              <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
            </div>
            <span className="font-medium text-sm">Wizard</span>
          </div>
        </div>
      </div>
      
      {/* User Stats */}
      <div className="space-y-4">
        <div className="text-sm text-gray-400">
          Good Evening Player
        </div>
        
        <div className="text-sm text-gray-400">
          Today: {new Date().toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' })}
        </div>
        
        <div className="flex items-center">
          <span className="text-sm mr-2">Total XP Left:</span>
          <span className="text-sm text-red-400 mr-1">{user?.xp || 0} XP</span>
          <svg className="w-4 h-4 text-red-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        </div>
        
        <div className="flex items-center">
          <span className="text-sm mr-2">Today:</span>
          <span className="text-sm text-yellow-400 mr-1">0 XP</span>
          <svg className="w-4 h-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
        </div>
        
        <div className="text-sm text-purple-400">
          Keep Going 0%
        </div>
        
        {/* Level Progress */}
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-1">
            <span>Level {user?.level || 1} Progress</span>
            <span>{user ? (user.xp % 100) : 0}%</span>
          </div>
          <Progress 
            value={user ? (user.xp % 100) : 0} 
            className="h-2 bg-gray-700" 
            indicatorClassName="bg-purple-500" 
          />
        </div>
      </div>
    </Card>
  );
};

export default StatusWindow;
