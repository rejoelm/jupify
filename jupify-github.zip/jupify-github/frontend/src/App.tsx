import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './components/ui/theme-provider';
import LandingPage from './pages/LandingPage';
import UserGuidePage from './pages/UserGuidePage';
import DashboardPage from './pages/DashboardPage';
import QuestsPage from './pages/QuestsPage';
import PortfolioPage from './pages/PortfolioPage';
import SkillTreePage from './pages/SkillTreePage';
import AchievementsPage from './pages/AchievementsPage';
import { WalletProvider } from './contexts/WalletContext';
import { UserProvider } from './contexts/UserContext';
import { Toaster } from './components/ui/toaster';
import './App.css';

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="jupify-theme">
      <WalletProvider>
        <UserProvider>
          <Router>
            <Routes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/guide" element={<UserGuidePage />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/quests" element={<QuestsPage />} />
              <Route path="/portfolio" element={<PortfolioPage />} />
              <Route path="/skill-tree" element={<SkillTreePage />} />
              <Route path="/achievements" element={<AchievementsPage />} />
            </Routes>
          </Router>
          <Toaster />
        </UserProvider>
      </WalletProvider>
    </ThemeProvider>
  );
}

export default App;
