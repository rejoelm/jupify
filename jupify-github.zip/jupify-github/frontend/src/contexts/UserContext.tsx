import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useWallet } from './WalletContext';

interface UserData {
  id: number;
  wallet_address: string;
  username: string | null;
  email: string | null;
  role: string | null;
  xp: number;
  level: number;
  created_at: string;
  updated_at: string;
  settings: {
    theme: string;
    notifications: boolean;
  };
}

interface UserProgress {
  badges: any[];
  active_quests: any[];
  completed_quests: any[];
  quest_completion_rate: number;
}

interface UserContextType {
  user: UserData | null;
  userProgress: UserProgress | null;
  loading: boolean;
  error: string | null;
  fetchUser: () => Promise<void>;
  fetchUserProgress: () => Promise<void>;
  updateUserProfile: (data: Partial<UserData>) => Promise<void>;
  selectRole: (role: string) => Promise<void>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const { walletAddress, connected } = useWallet();
  const [user, setUser] = useState<UserData | null>(null);
  const [userProgress, setUserProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch user data when wallet is connected
  useEffect(() => {
    if (connected && walletAddress) {
      fetchUser();
    } else {
      setUser(null);
      setUserProgress(null);
    }
  }, [connected, walletAddress]);

  const fetchUser = async () => {
    if (!walletAddress) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch(`http://localhost:5000/api/user/profile?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch user data');
      }
      
      const userData = await response.json();
      setUser(userData);
      
    } catch (error) {
      console.error('Error fetching user:', error);
      setError('Failed to load user data');
    } finally {
      setLoading(false);
    }
  };

  const fetchUserProgress = async () => {
    if (!walletAddress) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch(`http://localhost:5000/api/user/progress?wallet_address=${walletAddress}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch user progress');
      }
      
      const progressData = await response.json();
      setUserProgress(progressData);
      
    } catch (error) {
      console.error('Error fetching user progress:', error);
      setError('Failed to load user progress');
    } finally {
      setLoading(false);
    }
  };

  const updateUserProfile = async (data: Partial<UserData>) => {
    if (!walletAddress || !user) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch('http://localhost:5000/api/user/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet_address: walletAddress,
          ...data
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update user profile');
      }
      
      const updatedUser = await response.json();
      setUser(updatedUser.user);
      
    } catch (error) {
      console.error('Error updating user profile:', error);
      setError('Failed to update user profile');
    } finally {
      setLoading(false);
    }
  };

  const selectRole = async (role: string) => {
    if (!walletAddress) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch('http://localhost:5000/api/user/role', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          wallet_address: walletAddress,
          role
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to select role');
      }
      
      const result = await response.json();
      
      // Update user data with new role
      if (user) {
        setUser({
          ...user,
          role: result.role
        });
      }
      
    } catch (error) {
      console.error('Error selecting role:', error);
      setError('Failed to select role');
    } finally {
      setLoading(false);
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        userProgress,
        loading,
        error,
        fetchUser,
        fetchUserProgress,
        updateUserProfile,
        selectRole
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
