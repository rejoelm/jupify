import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface WalletContextType {
  connected: boolean;
  walletAddress: string | null;
  connecting: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState<boolean>(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [connecting, setConnecting] = useState<boolean>(false);

  // Check if wallet was previously connected
  useEffect(() => {
    const savedWalletAddress = localStorage.getItem('jupify-wallet-address');
    if (savedWalletAddress) {
      setWalletAddress(savedWalletAddress);
      setConnected(true);
    }
  }, []);

  const connectWallet = async () => {
    try {
      setConnecting(true);
      
      // Check if Phantom is installed
      const { solana } = window as any;
      
      if (!solana?.isPhantom) {
        alert('Phantom wallet is not installed. Please install it from https://phantom.app/');
        setConnecting(false);
        return;
      }
      
      // Connect to wallet
      const response = await solana.connect();
      const address = response.publicKey.toString();
      
      // Save wallet address
      setWalletAddress(address);
      setConnected(true);
      localStorage.setItem('jupify-wallet-address', address);
      
      // Register wallet with backend
      await fetch('http://localhost:5000/api/wallet/connect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ wallet_address: address }),
      });
      
    } catch (error) {
      console.error('Error connecting wallet:', error);
    } finally {
      setConnecting(false);
    }
  };

  const disconnectWallet = () => {
    try {
      const { solana } = window as any;
      
      if (solana) {
        solana.disconnect();
      }
      
      // Clear wallet data
      setWalletAddress(null);
      setConnected(false);
      localStorage.removeItem('jupify-wallet-address');
      
    } catch (error) {
      console.error('Error disconnecting wallet:', error);
    }
  };

  return (
    <WalletContext.Provider
      value={{
        connected,
        walletAddress,
        connecting,
        connectWallet,
        disconnectWallet,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
