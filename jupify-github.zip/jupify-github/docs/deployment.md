# Deployment Guide

This document provides instructions for deploying JUPIFY to production environments.

## Prerequisites

- Node.js 16+ and npm/pnpm
- Python 3.9+
- Solana CLI tools
- Docker and Docker Compose (optional)
- Access to hosting platforms (Vercel, Netlify, Heroku, etc.)
- Solana wallet with SOL for deployment transactions

## Frontend Deployment

### Option 1: Vercel/Netlify (Recommended)

1. Push your code to a GitHub repository
2. Connect your repository to Vercel or Netlify
3. Configure build settings:
   - Build command: `npm run build` or `pnpm build`
   - Output directory: `dist` or `build`
   - Environment variables:
     - `VITE_API_URL`: Backend API URL
     - `VITE_SOLANA_RPC_URL`: Solana RPC URL
     - `VITE_PROGRAM_ID`: Deployed program ID

4. Deploy

### Option 2: Static Hosting

1. Build the frontend:
   ```bash
   cd frontend
   npm install
   npm run build
   ```

2. Deploy the contents of the `dist` or `build` directory to any static hosting service (AWS S3, GitHub Pages, etc.)

3. Configure your hosting service to redirect all routes to `index.html` for client-side routing

## Backend Deployment

### Option 1: Heroku

1. Create a `Procfile` in the backend directory:
   ```
   web: gunicorn src.main:app
   ```

2. Add `gunicorn` to `requirements.txt`

3. Deploy to Heroku:
   ```bash
   heroku create jupify-api
   git push heroku main
   ```

4. Configure environment variables:
   ```bash
   heroku config:set DB_URL=your_database_url
   heroku config:set JWT_SECRET=your_jwt_secret
   heroku config:set SOLANA_RPC_URL=your_solana_rpc_url
   ```

### Option 2: Docker

1. Create a `Dockerfile` in the backend directory:
   ```dockerfile
   FROM python:3.9-slim

   WORKDIR /app

   COPY requirements.txt .
   RUN pip install --no-cache-dir -r requirements.txt

   COPY . .

   CMD ["gunicorn", "src.main:app", "--bind", "0.0.0.0:$PORT"]
   ```

2. Build and run the Docker image:
   ```bash
   docker build -t jupify-api .
   docker run -p 5000:5000 -e PORT=5000 -e DB_URL=your_database_url jupify-api
   ```

3. For production, consider using Docker Compose with a database service

### Option 3: Cloud Run/App Engine

1. Follow the Docker approach above
2. Deploy to your preferred cloud platform using their CLI tools or web console

## Database Setup

### PostgreSQL

1. Create a PostgreSQL database
2. Run the migration script:
   ```bash
   cd backend
   python src/db/migrate.py
   ```

3. Update the database URL in your environment variables

## Smart Contract Deployment

1. Build the program:
   ```bash
   cd smart-contract
   anchor build
   ```

2. Deploy to Solana devnet:
   ```bash
   anchor deploy --provider.cluster devnet
   ```

3. For mainnet deployment:
   ```bash
   anchor deploy --provider.cluster mainnet
   ```

4. Update the program ID in your frontend and backend configurations

## Environment Configuration

### Frontend Environment Variables

Create a `.env` file in the frontend directory:

```
VITE_API_URL=https://api.jupify.com
VITE_SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
VITE_PROGRAM_ID=your_deployed_program_id
```

### Backend Environment Variables

Create a `.env` file in the backend directory:

```
DB_URL=postgresql://user:password@localhost:5432/jupify
JWT_SECRET=your_jwt_secret
SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
PROGRAM_ID=your_deployed_program_id
PORT=5000
```

## SSL Configuration

For production deployments, ensure SSL is enabled:

1. For Heroku, Vercel, Netlify: SSL is provided automatically
2. For custom deployments: Use Let's Encrypt or your hosting provider's SSL options

## Monitoring and Logging

1. Set up application monitoring:
   - Sentry for error tracking
   - Datadog or New Relic for performance monitoring

2. Configure logging:
   - Use structured logging format
   - Set appropriate log levels for production

## Continuous Integration/Deployment

1. Set up GitHub Actions for CI/CD:
   - Run tests on pull requests
   - Deploy to staging on merge to develop branch
   - Deploy to production on merge to main branch

2. Example GitHub Actions workflow:
   ```yaml
   name: Deploy

   on:
     push:
       branches: [main]

   jobs:
     deploy:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v2
         - name: Deploy Frontend
           uses: vercel/action@v2
           with:
             vercel-token: ${{ secrets.VERCEL_TOKEN }}
             vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
             vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
             vercel-args: '--prod'
   ```

## Production Checklist

Before going live:

1. **Security**:
   - Ensure all secrets are stored securely
   - Enable rate limiting
   - Set up CORS properly
   - Implement input validation

2. **Performance**:
   - Optimize frontend bundle size
   - Enable caching where appropriate
   - Configure database indexes

3. **Reliability**:
   - Set up health checks
   - Configure auto-scaling if needed
   - Implement retry logic for external services

4. **Monitoring**:
   - Set up alerts for critical errors
   - Monitor API response times
   - Track user engagement metrics

## Troubleshooting

### Common Issues

1. **Database Connection Errors**:
   - Verify connection string
   - Check network access rules
   - Ensure database service is running

2. **API Errors**:
   - Check logs for detailed error messages
   - Verify environment variables
   - Test endpoints with Postman or curl

3. **Frontend Routing Issues**:
   - Ensure server is configured to serve index.html for all routes
   - Check for CORS issues in browser console

4. **Smart Contract Deployment Failures**:
   - Verify wallet has sufficient SOL
   - Check for program size limits
   - Validate transaction logs

## Support

For deployment assistance, contact the JUPIFY team:
- Email: support@jupify.com
- Discord: https://discord.gg/jupify
