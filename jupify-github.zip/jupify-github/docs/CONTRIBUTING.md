# Contributing to JUPIFY

Thank you for your interest in contributing to JUPIFY! This document provides guidelines and instructions for contributing to the project.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please read it before contributing.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check the issue tracker to avoid duplicates. When creating a bug report, include as many details as possible:

- Use a clear and descriptive title
- Describe the exact steps to reproduce the problem
- Describe the behavior you observed and what you expected to see
- Include screenshots if possible
- Include details about your environment (OS, browser, etc.)

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion:

- Use a clear and descriptive title
- Provide a detailed description of the proposed functionality
- Explain why this enhancement would be useful
- Include mockups or examples if applicable

### Pull Requests

- Fill in the required template
- Follow the coding style and conventions
- Include tests for new functionality
- Update documentation for any changed functionality
- Ensure all tests pass

## Development Setup

### Prerequisites

- Node.js 16+
- Python 3.9+
- Solana CLI tools
- Anchor Framework

### Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

### Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

### Smart Contract Setup

```bash
cd smart-contract
anchor build
anchor test
```

## Coding Guidelines

### JavaScript/TypeScript

- Follow the ESLint configuration
- Use TypeScript for type safety
- Write meaningful variable and function names
- Add JSDoc comments for functions and complex logic
- Use React functional components and hooks

Example:

```typescript
/**
 * Component for displaying user profile information
 * @param {Object} props - Component props
 * @param {User} props.user - User object containing profile data
 * @param {boolean} props.loading - Loading state
 */
const UserProfile: React.FC<UserProfileProps> = ({ user, loading }) => {
  if (loading) {
    return <LoadingSpinner />;
  }
  
  return (
    <div className="user-profile">
      <h2>{user.username}</h2>
      <p>Level: {user.level}</p>
      <p>XP: {user.xp}</p>
    </div>
  );
};
```

### Python

- Follow PEP 8 style guide
- Use type hints
- Write docstrings for functions and classes
- Use meaningful variable and function names

Example:

```python
from typing import List, Optional

def get_user_quests(user_id: int) -> List[dict]:
    """
    Retrieve all quests for a specific user.
    
    Args:
        user_id: The ID of the user
        
    Returns:
        A list of quest dictionaries
    """
    # Implementation
    pass
```

### Rust (Smart Contract)

- Follow Rust style guidelines
- Document public functions and modules
- Use meaningful error types
- Write unit tests for all functionality

Example:

```rust
/// Creates a new portfolio for the given user
pub fn create_portfolio(
    ctx: Context<CreatePortfolio>,
    name: String,
    description: String,
    risk_profile: String,
) -> Result<()> {
    let portfolio = &mut ctx.accounts.portfolio;
    let user = &ctx.accounts.user;
    
    portfolio.owner = user.key();
    portfolio.name = name;
    portfolio.description = description;
    portfolio.risk_profile = risk_profile;
    portfolio.created_at = Clock::get()?.unix_timestamp;
    
    Ok(())
}
```

## Testing Guidelines

### Frontend Tests

- Write unit tests for components using Jest and React Testing Library
- Write integration tests for key user flows
- Aim for at least 70% test coverage

### Backend Tests

- Write unit tests for models and utility functions
- Write API tests for endpoints
- Use pytest for testing

### Smart Contract Tests

- Write unit tests for individual instructions
- Write integration tests for complete workflows
- Test edge cases and error conditions

## Git Workflow

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Commit Messages

Follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

- `feat:` for new features
- `fix:` for bug fixes
- `docs:` for documentation changes
- `style:` for formatting changes
- `refactor:` for code refactoring
- `test:` for adding or modifying tests
- `chore:` for maintenance tasks

Example: `feat: add portfolio rebalancing feature`

## Documentation

- Update README.md with any necessary changes
- Update API documentation for new or modified endpoints
- Add JSDoc comments for new functions and components
- Update architecture documentation for significant changes

## Review Process

All contributions will be reviewed by maintainers:

1. Automated checks (linting, tests) must pass
2. Code review by at least one maintainer
3. Changes requested or approved
4. Merged by a maintainer

## License

By contributing to JUPIFY, you agree that your contributions will be licensed under the project's MIT License.
