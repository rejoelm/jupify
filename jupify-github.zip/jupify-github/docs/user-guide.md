# User Guide

Welcome to JUPIFY - where your DeFi journey becomes an epic RPG adventure! This guide will help you get started and make the most of your experience.

## Table of Contents

1. [Introduction](#introduction)
2. [Getting Started](#getting-started)
3. [Dashboard Overview](#dashboard-overview)
4. [Portfolio Management](#portfolio-management)
5. [Quests & Missions](#quests--missions)
6. [XP & Leveling](#xp--leveling)
7. [Skill Trees](#skill-trees)
8. [Achievements & Badges](#achievements--badges)
9. [Wallet Integration](#wallet-integration)
10. [Troubleshooting](#troubleshooting)

## Introduction

### Your Hero's Journey Begins

In the world of JUPIFY, you are the hero. Life is not just about routines—it's a quest for greatness! Every action, habit, and decision is a chapter in your personal RPG.

You awaken in the futuristic city of Jupiter, where blockchain magic empowers every citizen to reach their potential. But beware: the **Villains of Unproductivity**—procrastination, distractions, and unhealthy habits—lurk in the shadows. Your mission: conquer them and unlock your true power.

By joining the **Order of JUPIFY**, you'll earn **XP (Experience Points)** every time you complete a positive habit (staking, trading, DeFi, voting, minting NFTs). Success fuels your hero's journey: level up, unlock upgrades, and customize your RPG avatar.

**But beware:** skip habits or fall into bad routines, and you'll lose XP. The villains of negative habits will challenge your progress and test your willpower.

## Getting Started

### 1. Connect Your Wallet

To begin your journey, you'll need to connect your Solana wallet:

1. Click the "Connect Wallet" button in the top-right corner
2. Select your preferred wallet provider (Phantom, Solflare, etc.)
3. Approve the connection request in your wallet

### 2. Create Your Hero

After connecting your wallet, you'll be prompted to create your hero:

1. Choose a username
2. Select your starting role (Trading, DeFi, Community, Designer/NFT, or Meme Cult)
3. Customize your avatar
4. Complete the onboarding tutorial

### 3. Set Your First Goals

Before diving into the full experience, set up your initial goals:

1. Navigate to the "Quests" tab
2. Browse available daily quests
3. Select at least 3 quests to start with
4. Check your dashboard to see your active quests

## Dashboard Overview

Your dashboard is your command center for your JUPIFY journey. Here's what you'll find:

### Status Window

Located in the top-left corner, this shows:
- Your current level and XP
- Daily XP progress
- Active role and specialization

### Quick Actions

Located in the top-right corner, this provides:
- Shortcuts to create new habits
- Access to daily quests
- Quick portfolio rebalancing

### Life Areas

The central area displays your progress in different life categories:
- Trading (Spot/Perps)
- DeFi
- Community
- Designer/NFT
- Meme Cult

### Daily Habits

The bottom section shows:
- Today's completed habits
- Streaks and consistency metrics
- Upcoming habits

### Rewards

The sidebar displays:
- Available rewards
- Achievement badges
- Special events

## Portfolio Management

### Creating a Portfolio

1. Navigate to the "Portfolio" tab
2. Click "Create New Portfolio"
3. Name your portfolio and set a description
4. Choose a risk profile (Conservative, Moderate, Aggressive)
5. Click "Create"

### Adding Tokens

1. Open your portfolio
2. Click "Add Token"
3. Search for the token you want to add
4. Set your target allocation percentage
5. Click "Add"

### Rebalancing

1. From your portfolio view, click "Rebalance"
2. Review the suggested transactions
3. Adjust if needed
4. Click "Confirm Rebalance"
5. Approve the transactions in your wallet

### Tracking Performance

1. View your portfolio's performance chart
2. Toggle between different time periods (1D, 1W, 1M, 3M, 1Y, All)
3. Analyze allocation breakdown in the pie chart
4. Check individual token performance

## Quests & Missions

### Daily Quests

These reset every 24 hours and include:
- Learning about new Jupiter features
- Completing simple trading tasks
- Participating in community activities

To complete a daily quest:
1. Click on the quest in your dashboard
2. Follow the instructions
3. Submit proof of completion if required
4. Receive XP and rewards

### Achievement Paths

These are longer-term goals that track your progress:
- Portfolio growth milestones
- Trading volume achievements
- Community contribution recognition

View your progress in the "Achievements" tab.

### Skill Tree Missions

These are specialized quests based on your chosen role:
1. Navigate to the "Skill Tree" tab
2. Select a skill to develop
3. Complete the associated missions
4. Unlock new abilities and features

## XP & Leveling

### Earning XP

You earn XP by:
- Completing quests and missions
- Maintaining consistent habits
- Achieving portfolio milestones
- Contributing to the community

### Level Progression

As you accumulate XP, you'll progress through levels:
- Each level requires more XP than the last
- New levels unlock additional features and rewards
- Your level is displayed prominently in your profile

### XP Tracking

Monitor your XP progress:
1. Check the XP bar in your dashboard
2. View detailed XP history in the "Progress" tab
3. Analyze which activities earn you the most XP

## Skill Trees

### Choosing a Role

Your initial role selection determines your starting point in the skill tree:
- Trading (Spot/Perps): Focus on trading strategies and market analysis
- DeFi: Specialize in yield farming, liquidity provision, and protocol interactions
- Community: Excel at governance, social engagement, and network building
- Designer/NFT: Master NFT creation, collection, and marketplace navigation
- Meme Cult: Become a cultural curator and trend-setter

### Unlocking Skills

1. Navigate to the "Skill Tree" tab
2. Browse available skills in your chosen path
3. Spend skill points (earned through leveling) to unlock new abilities
4. Complete associated missions to master each skill

### Respecialization

If you want to change your focus:
1. Go to the "Skill Tree" tab
2. Click "Respec" (costs a small fee)
3. Reallocate your skill points
4. Confirm your new specialization

## Achievements & Badges

### Earning Badges

Badges are awarded for significant accomplishments:
1. Complete specific achievement requirements
2. Receive notification of badge award
3. View your badges in the "Achievements" tab
4. Display selected badges on your profile

### Badge Categories

- Beginner: First steps in the Jupiter ecosystem
- Explorer: Discovering new features and protocols
- Master: Demonstrating expertise in specific areas
- Legend: Exceptional accomplishments recognized by the community

### Badge Benefits

Some badges provide special benefits:
- Access to exclusive events
- Special visual effects for your avatar
- Bonus XP for related activities
- Recognition in community leaderboards

## Wallet Integration

### Supported Wallets

JUPIFY supports all major Solana wallets:
- Phantom
- Solflare
- Backpack
- Glow
- And more

### Wallet Security

Your security is paramount:
- JUPIFY never stores your private keys
- All transactions require explicit approval
- You can disconnect your wallet at any time
- Activity tracking is pseudonymous

### Transaction Signing

When using JUPIFY features that interact with the blockchain:
1. A transaction request will appear in your wallet
2. Review the details carefully
3. Approve or reject as appropriate
4. Wait for confirmation

## Troubleshooting

### Common Issues

**Wallet Connection Problems**
- Ensure your wallet extension is up to date
- Try refreshing the page
- Disconnect and reconnect your wallet

**Missing XP or Rewards**
- Allow time for blockchain confirmations
- Check your transaction history
- Contact support if issues persist

**Portfolio Data Discrepancies**
- Verify token prices from multiple sources
- Ensure all transactions are confirmed
- Refresh your portfolio data

### Getting Help

If you encounter any issues:
1. Check the FAQ section
2. Join our Discord community for peer support
3. Submit a support ticket through the "Help" menu
4. Email support@jupify.com

---

Remember, in JUPIFY, every habit is a quest, every day is an adventure, and you are always leveling up—both in the game and in real life. Ready to turn your routine into a legend? Your journey awaits!
