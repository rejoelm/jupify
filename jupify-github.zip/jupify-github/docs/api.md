# API Documentation

This document provides detailed information about the JUPIFY API endpoints, request/response formats, and authentication requirements.

## Base URL

```
https://api.jupify.com/v1
```

## Authentication

Most API endpoints require authentication. Include the JWT token in the Authorization header:

```
Authorization: Bearer <token>
```

To obtain a token, use the wallet authentication endpoint.

## Endpoints

### Authentication

#### Connect Wallet

```
POST /auth/connect
```

Authenticates a user with their Solana wallet signature.

**Request Body:**
```json
{
  "wallet_address": "string",
  "signature": "string",
  "message": "string"
}
```

**Response:**
```json
{
  "token": "string",
  "user": {
    "id": "string",
    "wallet_address": "string",
    "username": "string",
    "xp": "number",
    "level": "number",
    "role": "string"
  }
}
```

### User

#### Get User Profile

```
GET /user
```

Returns the current user's profile information.

**Response:**
```json
{
  "id": "string",
  "wallet_address": "string",
  "username": "string",
  "xp": "number",
  "level": "number",
  "role": "string",
  "created_at": "string",
  "badges": [
    {
      "id": "string",
      "name": "string",
      "description": "string",
      "image_url": "string"
    }
  ]
}
```

#### Update User Profile

```
PUT /user
```

Updates the current user's profile information.

**Request Body:**
```json
{
  "username": "string",
  "role": "string"
}
```

**Response:**
```json
{
  "id": "string",
  "wallet_address": "string",
  "username": "string",
  "xp": "number",
  "level": "number",
  "role": "string",
  "updated_at": "string"
}
```

#### Get User XP History

```
GET /user/xp/history
```

Returns the user's XP history.

**Query Parameters:**
- `range`: Time range (1w, 1m, 3m, 1y, all)

**Response:**
```json
{
  "history": [
    {
      "date": "string",
      "xp": "number",
      "level": "number",
      "daily_xp": "number"
    }
  ]
}
```

### Portfolio

#### List Portfolios

```
GET /portfolio
```

Returns a list of the user's portfolios.

**Response:**
```json
{
  "portfolios": [
    {
      "id": "string",
      "name": "string",
      "description": "string",
      "risk_profile": "string",
      "created_at": "string",
      "total_value": "number"
    }
  ]
}
```

#### Create Portfolio

```
POST /portfolio
```

Creates a new portfolio.

**Request Body:**
```json
{
  "name": "string",
  "description": "string",
  "risk_profile": "string"
}
```

**Response:**
```json
{
  "id": "string",
  "name": "string",
  "description": "string",
  "risk_profile": "string",
  "created_at": "string"
}
```

#### Get Portfolio

```
GET /portfolio/{id}
```

Returns a specific portfolio with its tokens.

**Response:**
```json
{
  "id": "string",
  "name": "string",
  "description": "string",
  "risk_profile": "string",
  "created_at": "string",
  "total_value": "number",
  "tokens": [
    {
      "id": "string",
      "symbol": "string",
      "name": "string",
      "mint": "string",
      "amount": "number",
      "value": "number",
      "current_allocation": "number",
      "target_allocation": "number",
      "price": "number"
    }
  ]
}
```

#### Add Token to Portfolio

```
POST /portfolio/{id}/token
```

Adds a token to a portfolio.

**Request Body:**
```json
{
  "symbol": "string",
  "target_allocation": "number"
}
```

**Response:**
```json
{
  "id": "string",
  "symbol": "string",
  "name": "string",
  "mint": "string",
  "target_allocation": "number"
}
```

#### Rebalance Portfolio

```
POST /portfolio/{id}/rebalance
```

Rebalances a portfolio to match target allocations.

**Response:**
```json
{
  "success": "boolean",
  "transactions": [
    {
      "from_token": "string",
      "to_token": "string",
      "amount": "number",
      "value": "number"
    }
  ]
}
```

#### Get Portfolio History

```
GET /portfolio/{id}/history
```

Returns the historical performance of a portfolio.

**Query Parameters:**
- `range`: Time range (1w, 1m, 3m, 1y, all)

**Response:**
```json
{
  "history": [
    {
      "date": "string",
      "value": "number"
    }
  ]
}
```

### Quests

#### List Quests

```
GET /quests
```

Returns available quests for the user.

**Query Parameters:**
- `type`: Quest type (daily, achievement, skill)
- `status`: Quest status (available, in_progress, completed)

**Response:**
```json
{
  "quests": [
    {
      "id": "string",
      "title": "string",
      "description": "string",
      "type": "string",
      "xp_reward": "number",
      "status": "string",
      "progress": "number",
      "progress_max": "number",
      "expires_at": "string"
    }
  ]
}
```

#### Start Quest

```
POST /quests/{id}/start
```

Starts a quest for the user.

**Response:**
```json
{
  "id": "string",
  "title": "string",
  "status": "string",
  "started_at": "string"
}
```

#### Complete Quest

```
POST /quests/{id}/complete
```

Marks a quest as completed.

**Request Body:**
```json
{
  "proof": "string" // Optional proof of completion
}
```

**Response:**
```json
{
  "id": "string",
  "title": "string",
  "status": "string",
  "completed_at": "string",
  "xp_earned": "number",
  "rewards": [
    {
      "type": "string",
      "value": "string"
    }
  ]
}
```

### Achievements

#### List Achievements

```
GET /achievements
```

Returns the user's achievements.

**Query Parameters:**
- `category`: Achievement category (beginner, portfolio, trading, etc.)

**Response:**
```json
{
  "achievements": [
    {
      "id": "string",
      "title": "string",
      "description": "string",
      "category": "string",
      "xp_reward": "number",
      "completed": "boolean",
      "completed_at": "string",
      "progress": "number",
      "progress_max": "number",
      "icon": "string"
    }
  ]
}
```

### Jupiter Integration

#### Get Token List

```
GET /jupiter/tokens
```

Returns a list of tokens supported by Jupiter.

**Response:**
```json
{
  "tokens": [
    {
      "symbol": "string",
      "name": "string",
      "mint": "string",
      "decimals": "number",
      "logo_uri": "string"
    }
  ]
}
```

#### Get Token Price

```
GET /jupiter/price
```

Returns the current price of a token.

**Query Parameters:**
- `mint`: Token mint address

**Response:**
```json
{
  "mint": "string",
  "symbol": "string",
  "price_usd": "number",
  "price_sol": "number",
  "updated_at": "string"
}
```

#### Get Swap Quote

```
GET /jupiter/swap/quote
```

Returns a quote for swapping tokens.

**Query Parameters:**
- `input_mint`: Input token mint address
- `output_mint`: Output token mint address
- `amount`: Amount to swap (in input token units)

**Response:**
```json
{
  "input_mint": "string",
  "output_mint": "string",
  "input_amount": "number",
  "output_amount": "number",
  "price_impact_pct": "number",
  "routes": [
    {
      "market_info": {
        "id": "string",
        "label": "string"
      },
      "in_amount": "number",
      "out_amount": "number"
    }
  ]
}
```

## Error Responses

All endpoints return standard error responses:

```json
{
  "error": {
    "code": "string",
    "message": "string",
    "details": {}
  }
}
```

Common error codes:
- `400`: Bad Request
- `401`: Unauthorized
- `403`: Forbidden
- `404`: Not Found
- `500`: Internal Server Error

## Rate Limiting

API requests are rate limited to 100 requests per minute per user. The following headers are included in responses:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 99
X-RateLimit-Reset: 1620000000
```

## Pagination

List endpoints support pagination with the following query parameters:

- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20, max: 100)

Responses include pagination metadata:

```json
{
  "data": [],
  "pagination": {
    "total": "number",
    "page": "number",
    "limit": "number",
    "pages": "number"
  }
}
```

## Versioning

The API is versioned through the URL path. The current version is `v1`.

## Changelog

### v1.0.0 (2025-05-20)
- Initial release
