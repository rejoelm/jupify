# JUPIFY Architecture Documentation

This document provides a detailed overview of the JUPIFY architecture, explaining how the frontend, backend, and smart contract components interact to create a gamified learning platform for the Jupiter ecosystem.

## System Overview

JUPIFY is built on a three-tier architecture:

1. **Frontend**: React application with Tailwind CSS and shadcn/ui components
2. **Backend**: Flask API server with SQLAlchemy for database management
3. **Smart Contract**: Solana program written in Rust using the Anchor framework

![Architecture Diagram](images/architecture-diagram.png)

## Frontend Architecture

The frontend is built with React and TypeScript, using modern patterns and libraries:

### Key Technologies

- **React**: UI library for building component-based interfaces
- **TypeScript**: Type-safe JavaScript for better developer experience
- **Tailwind CSS**: Utility-first CSS framework for styling
- **shadcn/ui**: High-quality UI components built on Radix UI
- **Recharts**: Composable charting library for data visualization
- **Framer Motion**: Animation library for smooth transitions

### Component Structure

```
frontend/
├── components/         # Reusable UI components
│   ├── ui/            # Base UI components (buttons, cards, etc.)
│   ├── StatusWindow.tsx
│   ├── QuestCard.tsx
│   ├── PortfolioWidget.tsx
│   ├── EventsWidget.tsx
│   ├── Sidebar.tsx
│   ├── PortfolioProgressChart.tsx
│   └── XPProgressChart.tsx
├── contexts/          # React context providers
│   ├── WalletContext.tsx
│   └── UserContext.tsx
├── hooks/             # Custom React hooks
├── lib/               # Utility functions
├── pages/             # Application pages
│   ├── LandingPage.tsx
│   ├── DashboardPage.tsx
│   ├── QuestsPage.tsx
│   ├── SkillTreePage.tsx
│   ├── AchievementsPage.tsx
│   ├── UserGuidePage.tsx
│   └── PortfolioPage.tsx
├── App.tsx            # Main application component
└── main.tsx           # Application entry point
```

### State Management

JUPIFY uses React Context API for global state management:

- **WalletContext**: Manages wallet connection and user authentication
- **UserContext**: Stores user profile, XP, level, and achievements

## Backend Architecture

The backend is built with Flask, providing RESTful API endpoints for the frontend:

### Key Technologies

- **Flask**: Lightweight web framework for Python
- **SQLAlchemy**: SQL toolkit and ORM for database operations
- **Flask-RESTful**: Extension for building REST APIs
- **JWT**: JSON Web Tokens for authentication

### API Structure

```
backend/
├── models/            # Database models
│   ├── user.py
│   ├── portfolio.py
│   ├── quest.py
│   ├── badge.py
│   └── event.py
├── routes/            # API endpoints
│   ├── user.py
│   ├── wallet.py
│   ├── portfolio.py
│   ├── quest.py
│   ├── xp.py
│   └── jupiter.py
├── static/            # Static files
└── main.py            # Application entry point
```

### Database Schema

The backend uses a relational database with the following key tables:

1. **Users**: Stores user profiles, XP, and level information
2. **Portfolios**: Manages user portfolios and their metadata
3. **PortfolioTokens**: Tracks tokens within portfolios
4. **Quests**: Defines available quests and their requirements
5. **UserQuests**: Tracks user progress on quests
6. **Badges**: Defines achievement badges
7. **UserBadges**: Tracks badges earned by users
8. **Events**: Stores Jupiter ecosystem events

## Smart Contract Architecture

The Solana smart contract is built using the Anchor framework:

### Key Components

- **User Account**: Stores user data on-chain
- **Portfolio Account**: Manages portfolio data
- **Achievement System**: Verifies and records achievements
- **XP System**: Manages experience points and level progression

### Program Structure

```
smart-contract/
├── lib.rs             # Main program file
├── instructions/      # Program instructions
├── state/            # Program state definitions
└── errors/           # Custom error definitions
```

### Key Instructions

1. **Initialize User**: Creates a new user account
2. **Create Portfolio**: Creates a new portfolio for a user
3. **Add Token**: Adds a token to a portfolio
4. **Rebalance Portfolio**: Updates token allocations
5. **Complete Quest**: Records quest completion and awards XP
6. **Award Badge**: Issues achievement badges to users

## Integration with Jupiter APIs

JUPIFY integrates with several Jupiter APIs:

1. **Jupiter Swap API**: Used for portfolio rebalancing and token swaps
2. **Jupiter Price API**: Provides real-time token pricing
3. **Jupiter Token List API**: Retrieves available tokens

The backend acts as a middleware between the frontend and Jupiter APIs, handling authentication, rate limiting, and data transformation.

## Authentication Flow

1. User connects wallet through frontend
2. Frontend sends wallet address to backend
3. Backend creates or retrieves user profile
4. Backend generates JWT token
5. Frontend stores token for authenticated requests

## Data Flow

### Portfolio Management Flow

1. User creates portfolio on frontend
2. Request sent to backend API
3. Backend creates portfolio record
4. Backend returns portfolio data
5. User adds tokens to portfolio
6. Backend calculates allocations using Jupiter Price API
7. Frontend displays portfolio with real-time data

### Quest Completion Flow

1. User completes quest requirements
2. Frontend sends completion request to backend
3. Backend verifies completion criteria
4. Backend awards XP and updates user level
5. If achievement criteria met, badge is awarded
6. Updated user data returned to frontend

## Deployment Architecture

JUPIFY can be deployed in various environments:

1. **Development**: Local deployment for development
2. **Testing**: Solana devnet for integration testing
3. **Production**: Solana mainnet for live deployment

The frontend can be deployed as a static site on any hosting service, while the backend requires a server with Python support.

## Security Considerations

1. **Wallet Security**: No private keys are stored
2. **API Authentication**: JWT tokens with expiration
3. **Input Validation**: All user inputs are validated
4. **Rate Limiting**: Prevents API abuse
5. **Error Handling**: Graceful error handling without exposing sensitive information

## Performance Optimizations

1. **Frontend Caching**: Local storage for non-sensitive data
2. **API Response Caching**: Reduces redundant API calls
3. **Lazy Loading**: Components and routes loaded on demand
4. **Pagination**: Large data sets are paginated
5. **Optimized Rendering**: React memo and useMemo for expensive components
