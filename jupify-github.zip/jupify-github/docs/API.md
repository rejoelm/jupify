# JUPIFY API Documentation

This document provides detailed information about the JUPIFY API endpoints, request/response formats, and authentication requirements.

## Base URL

```
Development: http://localhost:5000/api
Production: https://api.jupify.com/api
```

## Authentication

Most API endpoints require authentication using JWT tokens. Include the token in the Authorization header:

```
Authorization: Bearer <token>
```

To obtain a token, connect your wallet using the `/wallet/connect` endpoint.

## API Endpoints

### Wallet Management

#### Connect Wallet

```
POST /wallet/connect
```

Connects a wallet and returns user information and authentication token.

**Request Body:**
```json
{
  "wallet_address": "string"
}
```

**Response:**
```json
{
  "success": true,
  "user": {
    "id": "integer",
    "wallet_address": "string",
    "username": "string",
    "xp": "integer",
    "level": "integer",
    "role": "string",
    "created_at": "string (ISO date)"
  },
  "token": "string (JWT)"
}
```

### User Management

#### Get User Profile

```
GET /user
```

Returns the current user's profile information.

**Response:**
```json
{
  "success": true,
  "user": {
    "id": "integer",
    "wallet_address": "string",
    "username": "string",
    "xp": "integer",
    "level": "integer",
    "role": "string",
    "created_at": "string (ISO date)",
    "badges": [
      {
        "id": "integer",
        "name": "string",
        "description": "string",
        "image_url": "string",
        "earned_at": "string (ISO date)"
      }
    ]
  }
}
```

#### Update User Profile

```
PUT /user
```

Updates the current user's profile information.

**Request Body:**
```json
{
  "username": "string",
  "role": "string"
}
```

**Response:**
```json
{
  "success": true,
  "user": {
    "id": "integer",
    "wallet_address": "string",
    "username": "string",
    "xp": "integer",
    "level": "integer",
    "role": "string",
    "created_at": "string (ISO date)"
  }
}
```

### Portfolio Management

#### Get User Portfolios

```
GET /portfolio
```

Returns all portfolios for the current user.

**Response:**
```json
{
  "success": true,
  "portfolios": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "risk_profile": "string",
      "created_at": "string (ISO date)",
      "total_value": "number",
      "tokens": [
        {
          "id": "integer",
          "symbol": "string",
          "name": "string",
          "mint": "string",
          "amount": "number",
          "value": "number",
          "current_allocation": "number",
          "target_allocation": "number",
          "price": "number"
        }
      ]
    }
  ]
}
```

#### Create Portfolio

```
POST /portfolio
```

Creates a new portfolio for the current user.

**Request Body:**
```json
{
  "name": "string",
  "description": "string",
  "risk_profile": "string (conservative, moderate, aggressive)"
}
```

**Response:**
```json
{
  "success": true,
  "portfolio": {
    "id": "integer",
    "name": "string",
    "description": "string",
    "risk_profile": "string",
    "created_at": "string (ISO date)",
    "total_value": "number",
    "tokens": []
  }
}
```

#### Get Portfolio Details

```
GET /portfolio/:id
```

Returns detailed information about a specific portfolio.

**Response:**
```json
{
  "success": true,
  "portfolio": {
    "id": "integer",
    "name": "string",
    "description": "string",
    "risk_profile": "string",
    "created_at": "string (ISO date)",
    "total_value": "number",
    "tokens": [
      {
        "id": "integer",
        "symbol": "string",
        "name": "string",
        "mint": "string",
        "amount": "number",
        "value": "number",
        "current_allocation": "number",
        "target_allocation": "number",
        "price": "number"
      }
    ]
  }
}
```

#### Add Token to Portfolio

```
POST /portfolio/:id/token
```

Adds a token to a portfolio.

**Request Body:**
```json
{
  "symbol": "string",
  "target_allocation": "number"
}
```

**Response:**
```json
{
  "success": true,
  "token": {
    "id": "integer",
    "symbol": "string",
    "name": "string",
    "mint": "string",
    "amount": "number",
    "value": "number",
    "current_allocation": "number",
    "target_allocation": "number",
    "price": "number"
  }
}
```

#### Rebalance Portfolio

```
POST /portfolio/:id/rebalance
```

Rebalances a portfolio to match target allocations.

**Response:**
```json
{
  "success": true,
  "portfolio": {
    "id": "integer",
    "name": "string",
    "description": "string",
    "risk_profile": "string",
    "created_at": "string (ISO date)",
    "total_value": "number",
    "tokens": [
      {
        "id": "integer",
        "symbol": "string",
        "name": "string",
        "mint": "string",
        "amount": "number",
        "value": "number",
        "current_allocation": "number",
        "target_allocation": "number",
        "price": "number"
      }
    ],
    "rebalance_transactions": [
      {
        "from_token": "string",
        "to_token": "string",
        "amount": "number",
        "value": "number"
      }
    ]
  }
}
```

#### Get Portfolio History

```
GET /portfolio/history
```

Returns historical portfolio value data.

**Query Parameters:**
- `range`: Time range (1w, 1m, 3m, 1y, all)

**Response:**
```json
{
  "success": true,
  "history": [
    {
      "date": "string (ISO date)",
      "value": "number",
      "xp": "integer",
      "questsCompleted": "integer"
    }
  ]
}
```

### Quest Management

#### Get Available Quests

```
GET /quest
```

Returns all available quests for the current user.

**Response:**
```json
{
  "success": true,
  "quests": [
    {
      "id": "integer",
      "title": "string",
      "description": "string",
      "category": "string",
      "difficulty": "string",
      "xp_reward": "integer",
      "requirements": "string",
      "completed": "boolean",
      "progress": "integer",
      "progress_max": "integer"
    }
  ]
}
```

#### Start Quest

```
POST /quest/:id/start
```

Starts a quest for the current user.

**Response:**
```json
{
  "success": true,
  "quest": {
    "id": "integer",
    "title": "string",
    "description": "string",
    "category": "string",
    "difficulty": "string",
    "xp_reward": "integer",
    "requirements": "string",
    "completed": "boolean",
    "progress": "integer",
    "progress_max": "integer",
    "started_at": "string (ISO date)"
  }
}
```

#### Complete Quest

```
POST /quest/:id/complete
```

Marks a quest as completed and awards XP.

**Response:**
```json
{
  "success": true,
  "quest": {
    "id": "integer",
    "title": "string",
    "description": "string",
    "category": "string",
    "difficulty": "string",
    "xp_reward": "integer",
    "requirements": "string",
    "completed": "boolean",
    "completed_at": "string (ISO date)"
  },
  "xp_earned": "integer",
  "level_up": "boolean",
  "new_level": "integer",
  "badges_earned": [
    {
      "id": "integer",
      "name": "string",
      "description": "string",
      "image_url": "string"
    }
  ]
}
```

### XP and Achievements

#### Get XP History

```
GET /xp/history
```

Returns historical XP data.

**Query Parameters:**
- `range`: Time range (1w, 1m, 3m, 1y, all)

**Response:**
```json
{
  "success": true,
  "history": [
    {
      "date": "string (ISO date)",
      "xp": "integer",
      "level": "integer",
      "dailyXP": "integer",
      "questsCompleted": "integer",
      "questDistribution": {
        "daily": "integer",
        "achievement": "integer",
        "portfolio": "integer",
        "trading": "integer",
        "community": "integer"
      }
    }
  ]
}
```

#### Get Achievements

```
GET /achievements
```

Returns all achievements for the current user.

**Response:**
```json
{
  "success": true,
  "achievements": [
    {
      "id": "integer",
      "title": "string",
      "description": "string",
      "category": "string",
      "xp_reward": "integer",
      "completed": "boolean",
      "completed_at": "string (ISO date)",
      "progress": "integer",
      "progress_max": "integer",
      "icon": "string"
    }
  ]
}
```

### Jupiter API Integration

#### Get Token List

```
GET /jupiter/tokens
```

Returns a list of available tokens from Jupiter.

**Response:**
```json
{
  "success": true,
  "tokens": [
    {
      "symbol": "string",
      "name": "string",
      "mint": "string",
      "decimals": "integer",
      "logoURI": "string"
    }
  ]
}
```

#### Get Token Price

```
GET /jupiter/price/:mint
```

Returns the current price of a token.

**Response:**
```json
{
  "success": true,
  "price": "number",
  "mint": "string",
  "symbol": "string"
}
```

#### Get Swap Quote

```
POST /jupiter/quote
```

Returns a swap quote from Jupiter.

**Request Body:**
```json
{
  "inputMint": "string",
  "outputMint": "string",
  "amount": "string",
  "slippage": "number"
}
```

**Response:**
```json
{
  "success": true,
  "inputAmount": "string",
  "outputAmount": "string",
  "price": "number",
  "priceImpact": "number",
  "routes": [
    {
      "marketInfos": [
        {
          "amm": "string",
          "inputMint": "string",
          "outputMint": "string",
          "inAmount": "string",
          "outAmount": "string",
          "fee": "string"
        }
      ],
      "amount": "string",
      "outAmount": "string",
      "priceImpact": "number"
    }
  ]
}
```

## Error Handling

All API endpoints return standard error responses:

```json
{
  "success": false,
  "error": {
    "code": "string",
    "message": "string"
  }
}
```

Common error codes:

- `401`: Unauthorized - Authentication required
- `403`: Forbidden - Insufficient permissions
- `404`: Not Found - Resource not found
- `422`: Validation Error - Invalid request parameters
- `500`: Server Error - Internal server error

## Rate Limiting

API requests are rate-limited to prevent abuse. The current limits are:

- 60 requests per minute for authenticated users
- 10 requests per minute for unauthenticated users

Rate limit headers are included in all responses:

```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 59
X-RateLimit-Reset: 1620000000
```

## Pagination

List endpoints support pagination using the following query parameters:

- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20, max: 100)

Paginated responses include metadata:

```json
{
  "success": true,
  "data": [...],
  "pagination": {
    "total": "integer",
    "page": "integer",
    "limit": "integer",
    "pages": "integer"
  }
}
```

## Versioning

The API is versioned using URL path versioning. The current version is v1:

```
/api/v1/resource
```

## Webhooks

JUPIFY supports webhooks for real-time notifications. Configure webhooks in the developer dashboard.

Events include:
- `user.level_up`: User leveled up
- `quest.completed`: Quest completed
- `badge.earned`: Badge earned
- `portfolio.rebalanced`: Portfolio rebalanced
