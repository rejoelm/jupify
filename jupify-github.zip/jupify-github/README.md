# JUPIFY

![JUPIFY Logo](docs/images/jupify-logo.png)

JUPIFY is a gamified learning platform that helps users master the Jupiter ecosystem through interactive quests, portfolio management, and skill development.

## 🚀 Features

- **Portfolio Management**: Create virtual portfolios, track performance, and practice rebalancing with real-time data
- **Quest System**: Complete daily quests and achievements to learn about Jupiter's features
- **XP & Leveling**: Earn experience points and progress through levels to unlock new features
- **Skill Trees**: Specialize in different aspects of the Jupiter ecosystem (Trading, DeFi, Community, etc.)
- **Visual Progress Tracking**: Dynamic charts to visualize portfolio growth and XP progression
- **Achievement Badges**: Collect badges to showcase your expertise

## 📋 Table of Contents

- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Installation](#installation)
- [Usage](#usage)
- [Architecture](#architecture)
- [API Documentation](#api-documentation)
- [Contributing](#contributing)
- [License](#license)

## 🏗️ Project Structure

```
jupify/
├── frontend/           # React frontend application
├── backend/            # Flask backend API
├── smart-contract/     # Solana smart contract (Anchor)
└── docs/               # Documentation
```

## 🚦 Getting Started

### Prerequisites

- Node.js 16+
- Python 3.9+
- Solana CLI tools
- Anchor Framework
- Phantom or other Solana wallet

### Installation

#### Frontend

```bash
cd frontend
npm install
npm run dev
```

#### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

#### Smart Contract

```bash
cd smart-contract
anchor build
anchor deploy
```

## 🎮 Usage

1. Connect your Solana wallet
2. Complete the onboarding quests
3. Create your first portfolio
4. Choose a specialization path
5. Start earning XP and rewards

## 🏛️ Architecture

JUPIFY consists of three main components:

1. **Frontend**: React application with Tailwind CSS and shadcn/ui components
2. **Backend**: Flask API server with SQLAlchemy for database management
3. **Smart Contract**: Solana program written in Rust using the Anchor framework

For detailed architecture information, see [Architecture Documentation](docs/ARCHITECTURE.md).

## 📚 API Documentation

The JUPIFY API provides endpoints for:

- User management
- Portfolio operations
- Quest tracking
- XP and achievements
- Jupiter API integration

For detailed API documentation, see [API Documentation](docs/API.md).

## 👥 Contributing

We welcome contributions to JUPIFY! Please see our [Contributing Guidelines](docs/CONTRIBUTING.md) for more information.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
