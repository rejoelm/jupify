from flask import Blueprint, request, jsonify
from src.models.user import User
from src.main import db

xp_bp = Blueprint('xp', __name__)

@xp_bp.route('', methods=['GET'])
def get_user_xp():
    """Get user XP and level"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify({
        'xp': user.xp,
        'level': user.level,
        'next_level_xp': (user.level * 100),
        'progress_to_next_level': user.xp % 100
    }), 200

@xp_bp.route('/award', methods=['POST'])
def award_xp():
    """Award XP to user"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data or 'amount' not in data:
        return jsonify({'error': 'Wallet address and XP amount are required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    amount = int(data['amount'])
    if amount <= 0:
        return jsonify({'error': 'XP amount must be positive'}), 400
    
    # Award XP and check for level up
    old_level = user.level
    level_up = user.award_xp(amount)
    db.session.commit()
    
    return jsonify({
        'message': 'XP awarded successfully',
        'amount': amount,
        'new_total': user.xp,
        'level': user.level,
        'level_up': level_up,
        'old_level': old_level if level_up else None
    }), 200

@xp_bp.route('/leaderboard', methods=['GET'])
def get_xp_leaderboard():
    """Get XP leaderboard"""
    limit = request.args.get('limit', 10, type=int)
    
    # Get top users by XP
    top_users = User.query.order_by(User.xp.desc()).limit(limit).all()
    
    leaderboard = []
    for i, user in enumerate(top_users):
        leaderboard.append({
            'rank': i + 1,
            'wallet_address': user.wallet_address,
            'username': user.username or f'User {user.wallet_address[:6]}...{user.wallet_address[-4:]}',
            'xp': user.xp,
            'level': user.level
        })
    
    return jsonify({
        'leaderboard': leaderboard
    }), 200

@xp_bp.route('/levels', methods=['GET'])
def get_level_information():
    """Get information about levels and XP requirements"""
    # Define level thresholds and rewards
    levels = []
    for i in range(1, 21):  # Levels 1-20
        level_info = {
            'level': i,
            'xp_required': (i - 1) * 100,
            'title': get_level_title(i),
            'rewards': get_level_rewards(i)
        }
        levels.append(level_info)
    
    return jsonify({
        'levels': levels
    }), 200

def get_level_title(level):
    """Get title for level"""
    titles = {
        1: 'Novice Explorer',
        2: 'Apprentice Trader',
        3: 'Token Enthusiast',
        4: 'Market Observer',
        5: 'Portfolio Initiate',
        6: 'DeFi Dabbler',
        7: 'Swap Specialist',
        8: 'Yield Seeker',
        9: 'Risk Manager',
        10: 'Market Analyst',
        11: 'Portfolio Strategist',
        12: 'Liquidity Provider',
        13: 'Trend Spotter',
        14: 'Alpha Hunter',
        15: 'DeFi Architect',
        16: 'Market Sage',
        17: 'Whale Watcher',
        18: 'Trading Oracle',
        19: 'Jupiter Virtuoso',
        20: 'DeFi Grandmaster'
    }
    return titles.get(level, f'Level {level} Trader')

def get_level_rewards(level):
    """Get rewards for level"""
    # In a real implementation, this would return actual rewards
    # For now, return mock data
    rewards = []
    
    if level % 5 == 0:  # Every 5 levels
        rewards.append({
            'type': 'badge',
            'name': f'Level {level} Badge',
            'description': f'Awarded for reaching level {level}'
        })
    
    if level >= 10:  # Level 10 and above
        rewards.append({
            'type': 'feature',
            'name': 'Advanced Portfolio Analytics',
            'description': 'Access to advanced portfolio analytics tools'
        })
    
    if level >= 15:  # Level 15 and above
        rewards.append({
            'type': 'feature',
            'name': 'Custom Trading Strategies',
            'description': 'Ability to create and save custom trading strategies'
        })
    
    # All levels get some JUP tokens
    rewards.append({
        'type': 'token',
        'name': 'JUP Tokens',
        'amount': level * 5,
        'description': f'{level * 5} JUP tokens for reaching level {level}'
    })
    
    return rewards
