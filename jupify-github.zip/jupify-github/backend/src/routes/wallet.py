from flask import Blueprint, request, jsonify
from src.models.user import User
from src.main import db
import json

wallet_bp = Blueprint('wallet', __name__)

@wallet_bp.route('/connect', methods=['POST'])
def connect_wallet():
    """Connect wallet and create user if not exists"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    wallet_address = data['wallet_address']
    
    # Check if user exists
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        # Create new user
        user = User(wallet_address=wallet_address)
        db.session.add(user)
        db.session.commit()
        
        return jsonify({
            'message': 'User created successfully',
            'user': user.to_dict(),
            'is_new': True
        }), 201
    
    return jsonify({
        'message': 'User found',
        'user': user.to_dict(),
        'is_new': False
    }), 200

@wallet_bp.route('/disconnect', methods=['POST'])
def disconnect_wallet():
    """Disconnect wallet"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    return jsonify({'message': 'Wallet disconnected successfully'}), 200

@wallet_bp.route('/balance', methods=['GET'])
def get_wallet_balance():
    """Get wallet balance (mock implementation)"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    # In a real implementation, this would query the Solana blockchain
    # For now, return mock data
    mock_balance = {
        'sol': 10.5,
        'tokens': [
            {'mint': 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN', 'symbol': 'JUP', 'amount': 1000.0},
            {'mint': 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', 'symbol': 'USDC', 'amount': 500.0}
        ]
    }
    
    return jsonify(mock_balance), 200

@wallet_bp.route('/sign', methods=['POST'])
def sign_transaction():
    """Sign transaction (mock implementation)"""
    data = request.get_json()
    
    if not data or 'transaction' not in data or 'wallet_address' not in data:
        return jsonify({'error': 'Transaction and wallet address are required'}), 400
    
    # In a real implementation, this would return the transaction for signing by the wallet
    # For now, return mock data
    return jsonify({
        'message': 'Transaction ready for signing',
        'transaction': data['transaction']
    }), 200
