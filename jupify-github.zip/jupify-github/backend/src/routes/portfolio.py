from flask import Blueprint, request, jsonify
from src.models.portfolio import Portfolio, PortfolioToken
from src.models.user import User
from src.main import db

portfolio_bp = Blueprint('portfolio', __name__)

@portfolio_bp.route('', methods=['GET'])
def get_user_portfolios():
    """Get all portfolios for a user"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    portfolios = Portfolio.get_user_portfolios(user.id)
    
    return jsonify({
        'portfolios': [portfolio.to_dict() for portfolio in portfolios]
    }), 200

@portfolio_bp.route('', methods=['POST'])
def create_portfolio():
    """Create a new portfolio"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data or 'name' not in data:
        return jsonify({'error': 'Wallet address and portfolio name are required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Create portfolio
    portfolio = Portfolio(
        user_id=user.id,
        name=data['name'],
        description=data.get('description'),
        risk_profile=data.get('risk_profile', 'moderate')
    )
    
    db.session.add(portfolio)
    db.session.commit()
    
    # Award XP for creating portfolio
    user.award_xp(10)
    db.session.commit()
    
    return jsonify({
        'message': 'Portfolio created successfully',
        'portfolio': portfolio.to_dict()
    }), 201

@portfolio_bp.route('/<int:portfolio_id>', methods=['GET'])
def get_portfolio(portfolio_id):
    """Get portfolio details"""
    portfolio = Portfolio.query.get(portfolio_id)
    
    if not portfolio:
        return jsonify({'error': 'Portfolio not found'}), 404
    
    return jsonify(portfolio.to_dict()), 200

@portfolio_bp.route('/<int:portfolio_id>', methods=['PUT'])
def update_portfolio(portfolio_id):
    """Update portfolio details"""
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    portfolio = Portfolio.query.get(portfolio_id)
    
    if not portfolio:
        return jsonify({'error': 'Portfolio not found'}), 404
    
    # Update portfolio fields
    if 'name' in data:
        portfolio.name = data['name']
    if 'description' in data:
        portfolio.description = data['description']
    if 'risk_profile' in data:
        portfolio.risk_profile = data['risk_profile']
    
    db.session.commit()
    
    return jsonify({
        'message': 'Portfolio updated successfully',
        'portfolio': portfolio.to_dict()
    }), 200

@portfolio_bp.route('/<int:portfolio_id>/token', methods=['POST'])
def add_token_to_portfolio(portfolio_id):
    """Add token to portfolio"""
    data = request.get_json()
    
    if not data or 'mint' not in data or 'symbol' not in data or 'amount' not in data or 'target_allocation' not in data:
        return jsonify({'error': 'Token mint, symbol, amount, and target allocation are required'}), 400
    
    portfolio = Portfolio.query.get(portfolio_id)
    
    if not portfolio:
        return jsonify({'error': 'Portfolio not found'}), 404
    
    # Create portfolio token
    portfolio_token = PortfolioToken(
        portfolio_id=portfolio.id,
        mint=data['mint'],
        symbol=data['symbol'],
        amount=data['amount'],
        target_allocation=data['target_allocation']
    )
    
    db.session.add(portfolio_token)
    
    # Award XP for adding token
    user = User.query.get(portfolio.user_id)
    user.award_xp(5)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Token added to portfolio successfully',
        'token': portfolio_token.to_dict()
    }), 201

@portfolio_bp.route('/<int:portfolio_id>/rebalance', methods=['POST'])
def rebalance_portfolio(portfolio_id):
    """Rebalance portfolio based on target allocations"""
    portfolio = Portfolio.query.get(portfolio_id)
    
    if not portfolio:
        return jsonify({'error': 'Portfolio not found'}), 404
    
    # In a real implementation, this would interact with Jupiter Swap API
    # For now, just update the current allocations to match target allocations
    for token in portfolio.tokens:
        token.current_allocation = token.target_allocation
    
    # Award XP for rebalancing
    user = User.query.get(portfolio.user_id)
    user.award_xp(25)
    
    db.session.commit()
    
    return jsonify({
        'message': 'Portfolio rebalanced successfully',
        'portfolio': portfolio.to_dict()
    }), 200

@portfolio_bp.route('/<int:portfolio_id>/performance', methods=['GET'])
def get_portfolio_performance(portfolio_id):
    """Get portfolio performance metrics"""
    portfolio = Portfolio.query.get(portfolio_id)
    
    if not portfolio:
        return jsonify({'error': 'Portfolio not found'}), 404
    
    # In a real implementation, this would calculate actual performance
    # For now, return mock data
    performance = {
        'daily': 2.5,
        'weekly': -1.2,
        'monthly': 5.7,
        'all_time': 12.3,
        'risk_score': 65,
        'volatility': 'medium',
        'comparison_to_market': 1.2  # 1.2x market performance
    }
    
    return jsonify(performance), 200
