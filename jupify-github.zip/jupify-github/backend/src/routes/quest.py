from flask import Blueprint, request, jsonify
from src.models.quest import Quest, UserQuest
from src.models.user import User
from src.models.badge import Badge, UserBadge
from src.main import db
from datetime import datetime

quest_bp = Blueprint('quests', __name__)

@quest_bp.route('/daily', methods=['GET'])
def get_daily_quests():
    """Get daily quests"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Get all daily quests
    daily_quests = Quest.get_daily_quests()
    
    # Get user's active quests
    user_quests = UserQuest.get_user_active_quests(user.id)
    user_quest_ids = [uq.quest_id for uq in user_quests]
    
    # Format response
    quests_data = []
    for quest in daily_quests:
        quest_data = quest.to_dict()
        
        # Check if user has already started this quest
        if quest.id in user_quest_ids:
            user_quest = next((uq for uq in user_quests if uq.quest_id == quest.id), None)
            quest_data['user_progress'] = user_quest.progress
            quest_data['started'] = True
        else:
            quest_data['user_progress'] = 0
            quest_data['started'] = False
        
        quests_data.append(quest_data)
    
    return jsonify({
        'quests': quests_data
    }), 200

@quest_bp.route('/achievements', methods=['GET'])
def get_achievements():
    """Get achievement quests"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Get achievement quests
    achievement_quests = Quest.query.filter_by(type='achievement').all()
    
    # Get user's completed quests
    user_quests = UserQuest.get_user_completed_quests(user.id)
    completed_quest_ids = [uq.quest_id for uq in user_quests]
    
    # Format response
    achievements_data = []
    for quest in achievement_quests:
        quest_data = quest.to_dict()
        quest_data['completed'] = quest.id in completed_quest_ids
        
        if quest.id in completed_quest_ids:
            user_quest = next((uq for uq in user_quests if uq.quest_id == quest.id), None)
            quest_data['completed_at'] = user_quest.completed_at.isoformat() if user_quest.completed_at else None
        
        achievements_data.append(quest_data)
    
    return jsonify({
        'achievements': achievements_data
    }), 200

@quest_bp.route('/skills', methods=['GET'])
def get_skill_tree():
    """Get skill tree quests based on user role"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # If user has no role, return all role options
    if not user.role:
        roles = ['trading', 'defi', 'community', 'designer', 'meme']
        role_descriptions = {
            'trading': 'Master spot and perps trading strategies',
            'defi': 'Become a DeFi expert with deep protocol knowledge',
            'community': 'Build and nurture the Jupiter community',
            'designer': 'Create NFTs and visual assets for the ecosystem',
            'meme': 'Craft viral memes and content for Jupiter'
        }
        
        return jsonify({
            'message': 'Please select a role to view skill tree',
            'available_roles': [
                {'id': role, 'name': role.capitalize(), 'description': role_descriptions[role]}
                for role in roles
            ]
        }), 200
    
    # Get skill quests for user's role
    skill_quests = Quest.query.filter_by(type='skill', category=user.role).all()
    
    # Get user's quests
    user_quests = UserQuest.query.filter_by(user_id=user.id).all()
    user_quest_map = {uq.quest_id: uq for uq in user_quests}
    
    # Format response with skill tree structure
    skill_tree = {
        'role': user.role,
        'levels': {}
    }
    
    for quest in skill_quests:
        # Extract level from requirements
        level = quest.requirements.get('level', 1) if quest.requirements else 1
        
        if level not in skill_tree['levels']:
            skill_tree['levels'][level] = []
        
        quest_data = quest.to_dict()
        
        # Add user progress if available
        if quest.id in user_quest_map:
            user_quest = user_quest_map[quest.id]
            quest_data['progress'] = user_quest.progress
            quest_data['completed'] = user_quest.completed
            quest_data['completed_at'] = user_quest.completed_at.isoformat() if user_quest.completed_at else None
        else:
            quest_data['progress'] = 0
            quest_data['completed'] = False
            quest_data['completed_at'] = None
        
        skill_tree['levels'][level].append(quest_data)
    
    return jsonify(skill_tree), 200

@quest_bp.route('/<int:quest_id>/start', methods=['POST'])
def start_quest(quest_id):
    """Start a quest"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    quest = Quest.query.get(quest_id)
    
    if not quest:
        return jsonify({'error': 'Quest not found'}), 404
    
    # Check if user already started this quest
    existing_user_quest = UserQuest.query.filter_by(user_id=user.id, quest_id=quest.id).first()
    
    if existing_user_quest:
        return jsonify({
            'message': 'Quest already started',
            'user_quest': existing_user_quest.to_dict()
        }), 200
    
    # Create new user quest
    user_quest = UserQuest(user_id=user.id, quest_id=quest.id)
    db.session.add(user_quest)
    db.session.commit()
    
    return jsonify({
        'message': 'Quest started successfully',
        'user_quest': user_quest.to_dict()
    }), 201

@quest_bp.route('/<int:quest_id>/complete', methods=['POST'])
def complete_quest(quest_id):
    """Complete a quest"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Get user quest
    user_quest = UserQuest.query.filter_by(user_id=user.id, quest_id=quest_id).first()
    
    if not user_quest:
        return jsonify({'error': 'User has not started this quest'}), 404
    
    if user_quest.completed:
        return jsonify({'message': 'Quest already completed'}), 200
    
    # Get quest
    quest = Quest.query.get(quest_id)
    
    # Complete quest
    user_quest.update_progress(100)
    user_quest.completed = True
    user_quest.completed_at = datetime.utcnow()
    
    # Award XP
    level_up = user.award_xp(quest.xp_reward)
    
    # Award badge if applicable
    badge_awarded = None
    if quest.badge_reward:
        badge = Badge.query.filter_by(name=quest.badge_reward).first()
        
        if badge:
            user_badge = UserBadge(user_id=user.id, badge_id=badge.id)
            db.session.add(user_badge)
            badge_awarded = badge.to_dict()
    
    db.session.commit()
    
    return jsonify({
        'message': 'Quest completed successfully',
        'xp_awarded': quest.xp_reward,
        'level_up': level_up,
        'badge_awarded': badge_awarded,
        'user_quest': user_quest.to_dict()
    }), 200

@quest_bp.route('/progress', methods=['GET'])
def get_quest_progress():
    """Get user's quest progress"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Get user's quests
    active_quests = UserQuest.get_user_active_quests(user.id)
    completed_quests = UserQuest.get_user_completed_quests(user.id)
    
    # Calculate statistics
    total_quests = len(active_quests) + len(completed_quests)
    completion_rate = (len(completed_quests) / total_quests * 100) if total_quests > 0 else 0
    
    # Group completed quests by type
    completed_by_type = {}
    for uq in completed_quests:
        quest_type = uq.quest.type if uq.quest else 'unknown'
        if quest_type not in completed_by_type:
            completed_by_type[quest_type] = 0
        completed_by_type[quest_type] += 1
    
    return jsonify({
        'active_quests': [uq.to_dict() for uq in active_quests],
        'completed_quests': [uq.to_dict() for uq in completed_quests],
        'total_quests': total_quests,
        'completion_rate': completion_rate,
        'completed_by_type': completed_by_type
    }), 200
