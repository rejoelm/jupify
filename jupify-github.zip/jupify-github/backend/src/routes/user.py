from flask import Blueprint, request, jsonify
from src.models.user import User
from src.main import db

user_bp = Blueprint('user', __name__)

@user_bp.route('/profile', methods=['GET'])
def get_user_profile():
    """Get user profile"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    return jsonify(user.to_dict()), 200

@user_bp.route('/profile', methods=['PUT'])
def update_user_profile():
    """Update user profile"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Update user fields
    if 'username' in data:
        user.username = data['username']
    if 'email' in data:
        user.email = data['email']
    if 'role' in data:
        user.role = data['role']
    if 'settings' in data:
        user.settings = data['settings']
    
    db.session.commit()
    
    return jsonify({
        'message': 'User profile updated successfully',
        'user': user.to_dict()
    }), 200

@user_bp.route('/progress', methods=['GET'])
def get_user_progress():
    """Get user progress including XP, level, and achievements"""
    wallet_address = request.args.get('wallet_address')
    
    if not wallet_address:
        return jsonify({'error': 'Wallet address is required'}), 400
    
    user = User.get_by_wallet(wallet_address)
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Get user badges
    from src.models.badge import UserBadge
    user_badges = UserBadge.get_user_badges(user.id)
    
    # Get user quests
    from src.models.quest import UserQuest
    active_quests = UserQuest.get_user_active_quests(user.id)
    completed_quests = UserQuest.get_user_completed_quests(user.id)
    
    progress = {
        'user': user.to_dict(),
        'badges': [ub.to_dict() for ub in user_badges],
        'active_quests': [uq.to_dict() for uq in active_quests],
        'completed_quests': [uq.to_dict() for uq in completed_quests],
        'quest_completion_rate': len(completed_quests) / (len(active_quests) + len(completed_quests)) * 100 if (len(active_quests) + len(completed_quests)) > 0 else 0
    }
    
    return jsonify(progress), 200

@user_bp.route('/settings', methods=['PUT'])
def update_user_settings():
    """Update user settings"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data or 'settings' not in data:
        return jsonify({'error': 'Wallet address and settings are required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    user.settings = data['settings']
    db.session.commit()
    
    return jsonify({
        'message': 'User settings updated successfully',
        'settings': user.settings
    }), 200

@user_bp.route('/role', methods=['POST'])
def select_user_role():
    """Select user role"""
    data = request.get_json()
    
    if not data or 'wallet_address' not in data or 'role' not in data:
        return jsonify({'error': 'Wallet address and role are required'}), 400
    
    user = User.get_by_wallet(data['wallet_address'])
    
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Validate role
    valid_roles = ['trading', 'defi', 'community', 'designer', 'meme']
    if data['role'] not in valid_roles:
        return jsonify({'error': f'Invalid role. Must be one of: {", ".join(valid_roles)}'}), 400
    
    user.role = data['role']
    db.session.commit()
    
    return jsonify({
        'message': 'User role updated successfully',
        'role': user.role
    }), 200
