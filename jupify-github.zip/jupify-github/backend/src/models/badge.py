from src.main import db
from datetime import datetime

class Badge(db.Model):
    __tablename__ = 'badges'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.String(256), nullable=True)
    image = db.Column(db.String(256), nullable=True)
    category = db.Column(db.String(32), nullable=True)
    rarity = db.Column(db.String(32), nullable=True)  # common, rare, epic, legendary
    requirements = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user_badges = db.relationship('UserBadge', backref='badge', lazy=True)
    
    def __init__(self, name, description=None, image=None, category=None, rarity=None, requirements=None):
        self.name = name
        self.description = description
        self.image = image
        self.category = category
        self.rarity = rarity
        self.requirements = requirements or {}
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'image': self.image,
            'category': self.category,
            'rarity': self.rarity,
            'requirements': self.requirements,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @classmethod
    def get_by_category(cls, category):
        """Get badges by category"""
        return cls.query.filter_by(category=category).all()


class UserBadge(db.Model):
    __tablename__ = 'user_badges'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    badge_id = db.Column(db.Integer, db.ForeignKey('badges.id'), nullable=False)
    earned_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, user_id, badge_id):
        self.user_id = user_id
        self.badge_id = badge_id
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'badge_id': self.badge_id,
            'earned_at': self.earned_at.isoformat() if self.earned_at else None,
            'badge': self.badge.to_dict() if self.badge else None
        }
    
    @classmethod
    def get_user_badges(cls, user_id):
        """Get all badges earned by a user"""
        return cls.query.filter_by(user_id=user_id).all()
