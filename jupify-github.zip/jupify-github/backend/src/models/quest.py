from src.main import db
from datetime import datetime

class Quest(db.Model):
    __tablename__ = 'quests'
    
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(32), nullable=False)  # daily, achievement, skill
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    xp_reward = db.Column(db.Integer, default=0)
    badge_reward = db.Column(db.String(64), nullable=True)
    requirements = db.Column(db.JSON, nullable=True)
    category = db.Column(db.String(32), nullable=True)  # trading, defi, community, etc.
    difficulty = db.Column(db.String(16), nullable=True)  # beginner, intermediate, advanced
    expires_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user_quests = db.relationship('UserQuest', backref='quest', lazy=True)
    
    def __init__(self, type, title, description=None, xp_reward=0, badge_reward=None, 
                 requirements=None, category=None, difficulty=None, expires_at=None):
        self.type = type
        self.title = title
        self.description = description
        self.xp_reward = xp_reward
        self.badge_reward = badge_reward
        self.requirements = requirements or []
        self.category = category
        self.difficulty = difficulty
        self.expires_at = expires_at
    
    def to_dict(self):
        return {
            'id': self.id,
            'type': self.type,
            'title': self.title,
            'description': self.description,
            'xp_reward': self.xp_reward,
            'badge_reward': self.badge_reward,
            'requirements': self.requirements,
            'category': self.category,
            'difficulty': self.difficulty,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @classmethod
    def get_daily_quests(cls):
        """Get all active daily quests"""
        return cls.query.filter_by(type='daily').filter(
            (cls.expires_at > datetime.utcnow()) | (cls.expires_at.is_(None))
        ).all()
    
    @classmethod
    def get_quests_by_category(cls, category):
        """Get quests by category"""
        return cls.query.filter_by(category=category).all()


class UserQuest(db.Model):
    __tablename__ = 'user_quests'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    quest_id = db.Column(db.Integer, db.ForeignKey('quests.id'), nullable=False)
    progress = db.Column(db.Float, default=0.0)  # 0-100%
    completed = db.Column(db.Boolean, default=False)
    completed_at = db.Column(db.DateTime, nullable=True)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, user_id, quest_id):
        self.user_id = user_id
        self.quest_id = quest_id
        self.progress = 0.0
        self.completed = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'quest_id': self.quest_id,
            'progress': self.progress,
            'completed': self.completed,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'quest': self.quest.to_dict() if self.quest else None
        }
    
    def update_progress(self, progress):
        """Update quest progress and check for completion"""
        self.progress = min(progress, 100.0)
        
        if self.progress >= 100.0 and not self.completed:
            self.completed = True
            self.completed_at = datetime.utcnow()
            return True  # Indicates completion
        
        return False
    
    @classmethod
    def get_user_active_quests(cls, user_id):
        """Get all active quests for a user"""
        return cls.query.filter_by(user_id=user_id, completed=False).all()
    
    @classmethod
    def get_user_completed_quests(cls, user_id):
        """Get all completed quests for a user"""
        return cls.query.filter_by(user_id=user_id, completed=True).all()
