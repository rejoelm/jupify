from src.main import db
from datetime import datetime

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    wallet_address = db.Column(db.String(64), unique=True, nullable=False)
    username = db.Column(db.String(64), nullable=True)
    email = db.Column(db.String(120), nullable=True)
    role = db.Column(db.String(32), nullable=True)
    xp = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    settings = db.Column(db.JSON, nullable=True)
    
    # Relationships
    portfolios = db.relationship('Portfolio', backref='user', lazy=True)
    user_quests = db.relationship('UserQuest', backref='user', lazy=True)
    user_badges = db.relationship('UserBadge', backref='user', lazy=True)
    
    def __init__(self, wallet_address, username=None, email=None, role=None):
        self.wallet_address = wallet_address
        self.username = username
        self.email = email
        self.role = role
        self.xp = 0
        self.level = 1
        self.settings = {
            "theme": "dark",
            "notifications": True
        }
    
    def to_dict(self):
        return {
            'id': self.id,
            'wallet_address': self.wallet_address,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'xp': self.xp,
            'level': self.level,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'settings': self.settings
        }
    
    def award_xp(self, amount):
        """Award XP to user and check for level up"""
        self.xp += amount
        
        # Simple level calculation: level = 1 + (xp / 100)
        new_level = 1 + (self.xp // 100)
        if new_level > self.level:
            self.level = new_level
            return True  # Indicates level up
        return False
    
    @classmethod
    def get_by_wallet(cls, wallet_address):
        return cls.query.filter_by(wallet_address=wallet_address).first()
