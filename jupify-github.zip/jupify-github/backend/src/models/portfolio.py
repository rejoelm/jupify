from src.main import db
from datetime import datetime
import json

class Portfolio(db.Model):
    __tablename__ = 'portfolios'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.String(256), nullable=True)
    risk_profile = db.Column(db.String(32), nullable=True)
    total_value = db.Column(db.Float, default=0.0)
    performance = db.Column(db.JSON, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    tokens = db.relationship('PortfolioToken', backref='portfolio', lazy=True, cascade="all, delete-orphan")
    
    def __init__(self, user_id, name, description=None, risk_profile="moderate"):
        self.user_id = user_id
        self.name = name
        self.description = description
        self.risk_profile = risk_profile
        self.total_value = 0.0
        self.performance = {
            "daily": 0.0,
            "weekly": 0.0,
            "monthly": 0.0,
            "all_time": 0.0
        }
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'description': self.description,
            'risk_profile': self.risk_profile,
            'total_value': self.total_value,
            'performance': self.performance,
            'tokens': [token.to_dict() for token in self.tokens],
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def update_total_value(self, token_prices):
        """Update portfolio total value based on token prices"""
        total = 0.0
        for token in self.tokens:
            if token.mint in token_prices:
                token_value = token.amount * token_prices[token.mint]
                token.current_value = token_value
                total += token_value
        
        self.total_value = total
        return total
    
    def calculate_allocations(self):
        """Calculate current allocation percentages for each token"""
        if self.total_value == 0:
            return
            
        for token in self.tokens:
            token.current_allocation = (token.current_value / self.total_value) * 100
    
    @classmethod
    def get_user_portfolios(cls, user_id):
        return cls.query.filter_by(user_id=user_id).all()


class PortfolioToken(db.Model):
    __tablename__ = 'portfolio_tokens'
    
    id = db.Column(db.Integer, primary_key=True)
    portfolio_id = db.Column(db.Integer, db.ForeignKey('portfolios.id'), nullable=False)
    mint = db.Column(db.String(64), nullable=False)
    symbol = db.Column(db.String(16), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    target_allocation = db.Column(db.Float, nullable=False)
    current_allocation = db.Column(db.Float, nullable=True)
    current_value = db.Column(db.Float, nullable=True)
    
    def __init__(self, portfolio_id, mint, symbol, amount, target_allocation):
        self.portfolio_id = portfolio_id
        self.mint = mint
        self.symbol = symbol
        self.amount = amount
        self.target_allocation = target_allocation
        self.current_allocation = 0.0
        self.current_value = 0.0
    
    def to_dict(self):
        return {
            'id': self.id,
            'portfolio_id': self.portfolio_id,
            'mint': self.mint,
            'symbol': self.symbol,
            'amount': self.amount,
            'target_allocation': self.target_allocation,
            'current_allocation': self.current_allocation,
            'current_value': self.current_value
        }
