from src.main import db
from datetime import datetime

class Event(db.Model):
    __tablename__ = 'events'
    
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(32), nullable=False)  # community, ecosystem, news
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    image = db.Column(db.String(256), nullable=True)
    start_date = db.Column(db.DateTime, nullable=True)
    end_date = db.Column(db.DateTime, nullable=True)
    location = db.Column(db.String(128), nullable=True)
    url = db.Column(db.String(256), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, type, title, description=None, image=None, start_date=None, 
                 end_date=None, location=None, url=None):
        self.type = type
        self.title = title
        self.description = description
        self.image = image
        self.start_date = start_date
        self.end_date = end_date
        self.location = location
        self.url = url
    
    def to_dict(self):
        return {
            'id': self.id,
            'type': self.type,
            'title': self.title,
            'description': self.description,
            'image': self.image,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'location': self.location,
            'url': self.url,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @classmethod
    def get_upcoming_events(cls):
        """Get all upcoming events"""
        return cls.query.filter(
            (cls.end_date > datetime.utcnow()) | (cls.end_date.is_(None))
        ).order_by(cls.start_date).all()
    
    @classmethod
    def get_events_by_type(cls, type):
        """Get events by type"""
        return cls.query.filter_by(type=type).order_by(cls.start_date).all()
