import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import json
import logging

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configure database
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Import models after db initialization to avoid circular imports
from src.models.user import User
from src.models.portfolio import Portfolio
from src.models.quest import Quest, UserQuest
from src.models.badge import Badge
from src.models.event import Event

# Import and register blueprints
from src.routes.wallet import wallet_bp
from src.routes.user import user_bp
from src.routes.portfolio import portfolio_bp
from src.routes.quest import quest_bp
from src.routes.xp import xp_bp
from src.routes.jupiter import jupiter_bp
from src.routes.event import event_bp

app.register_blueprint(wallet_bp, url_prefix='/api/wallet')
app.register_blueprint(user_bp, url_prefix='/api/user')
app.register_blueprint(portfolio_bp, url_prefix='/api/portfolio')
app.register_blueprint(quest_bp, url_prefix='/api/quests')
app.register_blueprint(xp_bp, url_prefix='/api/xp')
app.register_blueprint(jupiter_bp, url_prefix='/api/jupiter')
app.register_blueprint(event_bp, url_prefix='/api/events')

# Root route
@app.route('/')
def index():
    return jsonify({
        "name": "JUPIFY API",
        "version": "1.0.0",
        "description": "Backend API for JUPIFY - A gamified learning platform for Jupiter users"
    })

# Health check endpoint
@app.route('/health')
def health():
    return jsonify({
        "status": "healthy",
        "database": "connected" if db.engine.connect() else "disconnected"
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Not Found",
        "message": "The requested resource was not found"
    }), 404

@app.errorhandler(500)
def server_error(error):
    logger.error(f"Server error: {error}")
    return jsonify({
        "error": "Internal Server Error",
        "message": "An unexpected error occurred"
    }), 500

# Create database tables
@app.before_first_request
def create_tables():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
