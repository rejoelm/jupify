use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use std::mem::size_of;

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS");

#[program]
pub mod jupify_protocol {
    use super::*;

    // User Management
    pub fn initialize_user(ctx: Context<InitializeUser>) -> Result<()> {
        let user_account = &mut ctx.accounts.user_account;
        user_account.owner = ctx.accounts.user.key();
        user_account.xp = 0;
        user_account.level = 1;
        user_account.total_achievements = 0;
        user_account.bump = *ctx.bumps.get("user_account").unwrap();
        
        msg!("User initialized with 0 XP at level 1");
        Ok(())
    }

    // Portfolio Management
    pub fn create_portfolio(ctx: Context<CreatePortfolio>, name: String) -> Result<()> {
        require!(name.len() <= 32, ErrorCode::NameTooLong);
        
        let portfolio = &mut ctx.accounts.portfolio;
        portfolio.owner = ctx.accounts.user.key();
        portfolio.name = name;
        portfolio.created_at = Clock::get()?.unix_timestamp;
        portfolio.last_updated = Clock::get()?.unix_timestamp;
        portfolio.total_value_usd = 0;
        portfolio.token_count = 0;
        portfolio.bump = *ctx.bumps.get("portfolio").unwrap();
        
        // Award XP for creating first portfolio
        let user_account = &mut ctx.accounts.user_account;
        award_xp(user_account, 10)?;
        
        msg!("Portfolio created: {}", name);
        emit!(PortfolioCreatedEvent {
            user: ctx.accounts.user.key(),
            portfolio: portfolio.key(),
            name: name,
        });
        
        Ok(())
    }

    pub fn add_token_to_portfolio(
        ctx: Context<AddTokenToPortfolio>,
        token_mint: Pubkey,
        amount: u64,
        target_allocation: u8,
    ) -> Result<()> {
        require!(target_allocation <= 100, ErrorCode::InvalidAllocation);
        
        let portfolio = &mut ctx.accounts.portfolio;
        require!(portfolio.token_count < 10, ErrorCode::PortfolioFull);
        
        let portfolio_token = &mut ctx.accounts.portfolio_token;
        portfolio_token.portfolio = portfolio.key();
        portfolio_token.token_mint = token_mint;
        portfolio_token.amount = amount;
        portfolio_token.target_allocation = target_allocation;
        portfolio_token.bump = *ctx.bumps.get("portfolio_token").unwrap();
        
        // Update portfolio
        portfolio.token_count += 1;
        portfolio.last_updated = Clock::get()?.unix_timestamp;
        
        // Award XP for adding token to portfolio
        let user_account = &mut ctx.accounts.user_account;
        award_xp(user_account, 5)?;
        
        msg!("Token added to portfolio");
        emit!(TokenAddedEvent {
            user: ctx.accounts.user.key(),
            portfolio: portfolio.key(),
            token_mint,
            amount,
            target_allocation,
        });
        
        Ok(())
    }

    pub fn rebalance_portfolio(ctx: Context<RebalancePortfolio>) -> Result<()> {
        // In a real implementation, this would interact with Jupiter Swap API in the client
        // Here we're just simulating the rebalancing action
        
        // Update portfolio last_updated timestamp
        let portfolio = &mut ctx.accounts.portfolio;
        portfolio.last_updated = Clock::get()?.unix_timestamp;
        
        // Award XP for rebalancing
        let user_account = &mut ctx.accounts.user_account;
        award_xp(user_account, 25)?;
        
        // Check if achievement criteria are met
        // For this example, we'll award an achievement if this is the user's first rebalance
        let achievement_account = &mut ctx.accounts.achievement;
        if achievement_account.completed_at == 0 {
            achievement_account.user = ctx.accounts.user.key();
            achievement_account.achievement_type = AchievementType::SuccessfulRebalance as u8;
            achievement_account.name = "Portfolio Maestro".to_string();
            achievement_account.completed_at = Clock::get()?.unix_timestamp;
            achievement_account.bump = *ctx.bumps.get("achievement").unwrap();
            
            // Update user achievement count
            user_account.total_achievements += 1;
            
            // Award bonus XP for achievement
            award_xp(user_account, 50)?;
            
            emit!(AchievementCompletedEvent {
                user: ctx.accounts.user.key(),
                achievement_type: AchievementType::SuccessfulRebalance as u8,
                achievement_name: "Portfolio Maestro".to_string(),
                xp_reward: 50,
            });
        }
        
        msg!("Portfolio rebalanced");
        emit!(PortfolioRebalancedEvent {
            user: ctx.accounts.user.key(),
            portfolio: portfolio.key(),
        });
        
        Ok(())
    }

    // XP and Achievement System
    pub fn award_xp(ctx: Context<AwardXP>, amount: u64) -> Result<()> {
        let user_account = &mut ctx.accounts.user_account;
        
        // Award XP
        award_xp(user_account, amount)?;
        
        msg!("XP awarded: {}", amount);
        emit!(XpAwardedEvent {
            user: ctx.accounts.user.key(),
            amount,
            new_total: user_account.xp,
        });
        
        Ok(())
    }

    pub fn complete_achievement(
        ctx: Context<CompleteAchievement>,
        achievement_type: u8,
        achievement_name: String,
    ) -> Result<()> {
        require!(achievement_name.len() <= 32, ErrorCode::NameTooLong);
        
        // Record achievement completion
        let achievement = &mut ctx.accounts.achievement;
        achievement.user = ctx.accounts.user.key();
        achievement.achievement_type = achievement_type;
        achievement.name = achievement_name.clone();
        achievement.completed_at = Clock::get()?.unix_timestamp;
        achievement.bump = *ctx.bumps.get("achievement").unwrap();
        
        // Update user achievement count
        let user_account = &mut ctx.accounts.user_account;
        user_account.total_achievements += 1;
        
        // Award XP for achievement
        let xp_reward = calculate_achievement_xp(achievement_type);
        award_xp(user_account, xp_reward)?;
        
        msg!("Achievement completed: {}", achievement_name);
        emit!(AchievementCompletedEvent {
            user: ctx.accounts.user.key(),
            achievement_type,
            achievement_name: achievement_name.clone(),
            xp_reward,
        });
        
        Ok(())
    }

    // Reward Distribution
    pub fn initialize_reward_pool(
        ctx: Context<InitializeRewardPool>,
        reward_token_mint: Pubkey,
        total_amount: u64,
    ) -> Result<()> {
        let reward_pool = &mut ctx.accounts.reward_pool;
        reward_pool.authority = ctx.accounts.authority.key();
        reward_pool.reward_token_mint = reward_token_mint;
        reward_pool.total_amount = total_amount;
        reward_pool.remaining_amount = total_amount;
        reward_pool.bump = *ctx.bumps.get("reward_pool").unwrap();
        
        msg!("Reward pool initialized with {} tokens", total_amount);
        emit!(RewardPoolInitializedEvent {
            authority: ctx.accounts.authority.key(),
            reward_token_mint,
            total_amount,
        });
        
        Ok(())
    }

    pub fn distribute_reward(
        ctx: Context<DistributeReward>,
        amount: u64,
        reason: String,
    ) -> Result<()> {
        require!(reason.len() <= 64, ErrorCode::ReasonTooLong);
        
        let reward_pool = &mut ctx.accounts.reward_pool;
        require!(reward_pool.remaining_amount >= amount, ErrorCode::InsufficientRewardFunds);
        
        // Transfer tokens from reward pool to user
        let seeds = &[
            b"reward_pool".as_ref(),
            &[reward_pool.bump],
        ];
        let signer = &[&seeds[..]];
        
        let cpi_accounts = Transfer {
            from: ctx.accounts.reward_pool_token_account.to_account_info(),
            to: ctx.accounts.user_token_account.to_account_info(),
            authority: ctx.accounts.reward_pool_signer.to_account_info(),
        };
        
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new_with_signer(cpi_program, cpi_accounts, signer);
        
        token::transfer(cpi_ctx, amount)?;
        
        // Update reward pool remaining amount
        reward_pool.remaining_amount -= amount;
        
        msg!("Reward distributed: {} tokens", amount);
        emit!(RewardDistributedEvent {
            user: ctx.accounts.user.key(),
            amount,
            reason,
        });
        
        Ok(())
    }
}

// Helper functions
fn award_xp(user_account: &mut Account<UserAccount>, amount: u64) -> Result<()> {
    user_account.xp += amount;
    
    // Check for level up
    let new_level = calculate_level(user_account.xp);
    if new_level > user_account.level {
        user_account.level = new_level;
    }
    
    Ok(())
}

fn calculate_level(xp: u64) -> u8 {
    // Simple level calculation: level = 1 + (xp / 100)
    // This can be adjusted for different progression curves
    let level = 1 + (xp / 100) as u8;
    std::cmp::min(level, 100) // Cap at level 100
}

fn calculate_achievement_xp(achievement_type: u8) -> u64 {
    // Different achievement types award different XP amounts
    match achievement_type {
        1 => 10,  // Basic achievements
        2 => 25,  // Intermediate achievements
        3 => 50,  // Advanced achievements
        4 => 100, // Expert achievements
        _ => 5,   // Default for unknown types
    }
}

// Account structures
#[account]
pub struct UserAccount {
    pub owner: Pubkey,
    pub xp: u64,
    pub level: u8,
    pub total_achievements: u16,
    pub bump: u8,
}

#[account]
pub struct Portfolio {
    pub owner: Pubkey,
    pub name: String,
    pub created_at: i64,
    pub last_updated: i64,
    pub total_value_usd: u64,
    pub token_count: u8,
    pub bump: u8,
}

#[account]
pub struct PortfolioToken {
    pub portfolio: Pubkey,
    pub token_mint: Pubkey,
    pub amount: u64,
    pub target_allocation: u8, // Percentage (0-100)
    pub bump: u8,
}

#[account]
pub struct Achievement {
    pub user: Pubkey,
    pub achievement_type: u8,
    pub name: String,
    pub completed_at: i64,
    pub bump: u8,
}

#[account]
pub struct RewardPool {
    pub authority: Pubkey,
    pub reward_token_mint: Pubkey,
    pub total_amount: u64,
    pub remaining_amount: u64,
    pub bump: u8,
}

// Context structures
#[derive(Accounts)]
pub struct InitializeUser<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(
        init,
        payer = user,
        space = 8 + size_of::<UserAccount>(),
        seeds = [b"user", user.key().as_ref()],
        bump
    )]
    pub user_account: Account<'info, UserAccount>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CreatePortfolio<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(
        mut,
        seeds = [b"user", user.key().as_ref()],
        bump = user_account.bump
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 32 + 32 + 8 + 8 + 8 + 1 + 1, // Base + name + pubkey + 3 timestamps + token_count + bump
        seeds = [b"portfolio", user.key().as_ref(), &[user_account.total_achievements as u8]],
        bump
    )]
    pub portfolio: Account<'info, Portfolio>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AddTokenToPortfolio<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(
        mut,
        seeds = [b"user", user.key().as_ref()],
        bump = user_account.bump,
        constraint = user_account.owner == user.key()
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(
        mut,
        seeds = [b"portfolio", user.key().as_ref(), &[portfolio.token_count]],
        bump = portfolio.bump,
        constraint = portfolio.owner == user.key()
    )]
    pub portfolio: Account<'info, Portfolio>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 32 + 32 + 8 + 1 + 1, // Base + portfolio pubkey + token_mint + amount + allocation + bump
        seeds = [b"portfolio_token", portfolio.key().as_ref(), &[portfolio.token_count]],
        bump
    )]
    pub portfolio_token: Account<'info, PortfolioToken>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RebalancePortfolio<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(
        mut,
        seeds = [b"user", user.key().as_ref()],
        bump = user_account.bump,
        constraint = user_account.owner == user.key()
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(
        mut,
        seeds = [b"portfolio", user.key().as_ref(), &[portfolio.token_count]],
        bump = portfolio.bump,
        constraint = portfolio.owner == user.key()
    )]
    pub portfolio: Account<'info, Portfolio>,
    
    #[account(
        init_if_needed,
        payer = user,
        space = 8 + 32 + 1 + 32 + 8 + 1, // Base + user pubkey + type + name + timestamp + bump
        seeds = [b"achievement", user.key().as_ref(), &[AchievementType::SuccessfulRebalance as u8]],
        bump
    )]
    pub achievement: Account<'info, Achievement>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AwardXP<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    
    #[account(mut)]
    pub user: SystemAccount<'info>,
    
    #[account(
        mut,
        seeds = [b"user", user.key().as_ref()],
        bump = user_account.bump
    )]
    pub user_account: Account<'info, UserAccount>,
}

#[derive(Accounts)]
pub struct CompleteAchievement<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    
    #[account(
        mut,
        seeds = [b"user", user.key().as_ref()],
        bump = user_account.bump,
        constraint = user_account.owner == user.key()
    )]
    pub user_account: Account<'info, UserAccount>,
    
    #[account(
        init,
        payer = user,
        space = 8 + 32 + 1 + 32 + 8 + 1, // Base + user pubkey + type + name + timestamp + bump
        seeds = [b"achievement", user.key().as_ref(), &[achievement_type]],
        bump
    )]
    pub achievement: Account<'info, Achievement>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct InitializeRewardPool<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    
    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 32 + 8 + 8 + 1, // Base + authority + token_mint + total + remaining + bump
        seeds = [b"reward_pool"],
        bump
    )]
    pub reward_pool: Account<'info, RewardPool>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct DistributeReward<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    
    pub user: SystemAccount<'info>,
    
    #[account(
        mut,
        seeds = [b"reward_pool"],
        bump = reward_pool.bump
    )]
    pub reward_pool: Account<'info, RewardPool>,
    
    /// CHECK: This is the PDA that signs for the reward pool
    #[account(
        seeds = [b"reward_pool"],
        bump = reward_pool.bump
    )]
    pub reward_pool_signer: UncheckedAccount<'info>,
    
    #[account(
        mut,
        constraint = reward_pool_token_account.mint == reward_pool.reward_token_mint,
        constraint = reward_pool_token_account.owner == reward_pool_signer.key()
    )]
    pub reward_pool_token_account: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        constraint = user_token_account.mint == reward_pool.reward_token_mint,
        constraint = user_token_account.owner == user.key()
    )]
    pub user_token_account: Account<'info, TokenAccount>,
    
    pub token_program: Program<'info, Token>,
}

// Enums
#[derive(Clone, Copy, PartialEq)]
pub enum AchievementType {
    SuccessfulRebalance = 1,
    PortfolioPerformance = 2,
    DiversificationMaster = 3,
    LearningCompletion = 4,
}

// Events
#[event]
pub struct PortfolioCreatedEvent {
    pub user: Pubkey,
    pub portfolio: Pubkey,
    pub name: String,
}

#[event]
pub struct TokenAddedEvent {
    pub user: Pubkey,
    pub portfolio: Pubkey,
    pub token_mint: Pubkey,
    pub amount: u64,
    pub target_allocation: u8,
}

#[event]
pub struct PortfolioRebalancedEvent {
    pub user: Pubkey,
    pub portfolio: Pubkey,
}

#[event]
pub struct XpAwardedEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub new_total: u64,
}

#[event]
pub struct AchievementCompletedEvent {
    pub user: Pubkey,
    pub achievement_type: u8,
    pub achievement_name: String,
    pub xp_reward: u64,
}

#[event]
pub struct RewardPoolInitializedEvent {
    pub authority: Pubkey,
    pub reward_token_mint: Pubkey,
    pub total_amount: u64,
}

#[event]
pub struct RewardDistributedEvent {
    pub user: Pubkey,
    pub amount: u64,
    pub reason: String,
}

// Error codes
#[error_code]
pub enum ErrorCode {
    #[msg("Name too long")]
    NameTooLong,
    #[msg("Invalid allocation percentage")]
    InvalidAllocation,
    #[msg("Portfolio is full")]
    PortfolioFull,
    #[msg("Insufficient reward funds")]
    InsufficientRewardFunds,
    #[msg("Reason too long")]
    ReasonTooLong,
}
